import express from 'express';
import dotenv from 'dotenv';
import cors from 'cors';
import connectDB from './config/db.js'; 

import spotifyRoutes from './routes/spotifyRoutes.js';
import artistRoutes from './routes/artistRoutes.js'; 
import songRoutes from './routes/songRoutes.js';
import setlistRoutes from './routes/setlistRoutes.js';
import userRoutes from './routes/userRoutes.js';


dotenv.config();

connectDB();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json()); 
app.use(express.urlencoded({ extended: true }));

app.use('/api/spotify', spotifyRoutes);

app.use('/api/artists', artistRoutes);

app.use('/api/songs', songRoutes);

app.use('/api/setlists', setlistRoutes);

app.use('/api/users', userRoutes);

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});

