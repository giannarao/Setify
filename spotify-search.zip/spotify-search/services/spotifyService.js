import axios from 'axios';
import { getAccessToken } from '../config/spotifyAuth.js';

export const searchArtists = async (artistName) => {
    const token = await getAccessToken();
    const response = await axios.get(
        `https://api.spotify.com/v1/search?q=${encodeURIComponent(artistName)}&type=artist`,
        { headers: { Authorization: `Bearer ${token}` } }
    );

    return response.data.artists.items.map(artist => artist.name);
};


export const searchSongs = async (songTitle) => {
    const token = await getAccessToken();
    const response = await axios.get(
        `https://api.spotify.com/v1/search?q=${encodeURIComponent(songTitle)}&type=track`,
        { headers: { Authorization: `Bearer ${token}` } }
    );

    return response.data.tracks.items.map(track => track.name);
};


export const searchSongWithArtist = async (songTitle) => {
    const token = await getAccessToken();
    const response = await axios.get(
        `https://api.spotify.com/v1/search?q=${encodeURIComponent(songTitle)}&type=track`,
        { headers: { Authorization: `Bearer ${token}` } }
    );

    return response.data.tracks.items.map(track => ({
        song: track.name,
        artist: track.artists.map(artist => artist.name).join(', '),
    }));
};


export const searchArtistSongs = async (artistName) => {
    const token = await getAccessToken();
    const artistResponse = await axios.get(
        `https://api.spotify.com/v1/search?q=${encodeURIComponent(artistName)}&type=artist`,
        { headers: { Authorization: `Bearer ${token}` } }
    );

    if (!artistResponse.data.artists.items.length) {
        throw new Error('Artist not found');
    }

    const artistId = artistResponse.data.artists.items[0].id;
    const tracksResponse = await axios.get(
        `https://api.spotify.com/v1/artists/${artistId}/top-tracks?market=US`,
        { headers: { Authorization: `Bearer ${token}` } }
    );

    return tracksResponse.data.tracks.map(track => ({
        title: track.name,
        artist: artistResponse.data.artists.items[0].name,
    }));
};



