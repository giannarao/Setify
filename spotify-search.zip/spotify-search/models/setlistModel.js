import mongoose from 'mongoose';

const setlistSchema = new mongoose.Schema({
  setlistName: {
    type: String,
    required: true  
  },
  setlistImage: {
    type: String,
    required: false  
  },
  createdBy: {
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'User', 
    required: true 
  },
  tourName: {
    type: String,
    required: false  
  },
  headlinerName: {
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Artist', 
    required: true 
  },
  date_location: [{
    date: {
      type: Date,
      required: true   
    },
    city: {
      type: String,
      required: true 
    }
  }],
  openerNames: [{
    name: {
      type: mongoose.Schema.Types.ObjectId, 
      ref: 'Artist', 
      required: false  
    },
    songs: [{
      type: mongoose.Schema.Types.ObjectId, 
      ref: 'Song', 
      required: false  
    }]
  }],
  headlinerSongIDs: [{
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Song', 
    required: true 
  }]
}, { 
  versionKey: false, 
  collection: 'setlist',
  toJSON: {
    transform: function (doc, ret) {
      if (Array.isArray(ret.date_location)) {
        ret.date_location.forEach(item => {
          delete item._id; 
        });
      }

      if (Array.isArray(ret.openerNames)) {
        ret.openerNames.forEach(opener => {
          opener.songs = opener.songs || [];
        });
      }
      
      return ret;
    }
  },
  toObject: {
    transform: function (doc, ret) {
      if (Array.isArray(ret.date_location)) {
        ret.date_location.forEach(item => {
          delete item._id;  
        });
      }

      if (Array.isArray(ret.openerNames)) {
        ret.openerNames.forEach(opener => {
          opener.songs = opener.songs || [];
        });
      }

      return ret;
    }
  }
});

const Setlist = mongoose.model('Setlist', setlistSchema);

export default Setlist;