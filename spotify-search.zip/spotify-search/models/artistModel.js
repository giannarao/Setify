import mongoose from 'mongoose';

const artistSchema = new mongoose.Schema({
  artistName: {
    type: String,
    required: true,
  },
  artistImage: {
    type: String,
    required: false,
  }
}, { versionKey: false, collection: 'artist' }); 

const Artist = mongoose.model('Artist', artistSchema);

export default Artist;


