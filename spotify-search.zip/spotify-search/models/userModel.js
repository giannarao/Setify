import mongoose from 'mongoose';

const userSchema = new mongoose.Schema({
  email: {
    type: String,
    required: true,
    unique: true
  },
  name: {
    type: String,
    required: true
  },
  password: {
    type: String,
    required: true
  },
  favoriteSetlists: [{
    // type: mongoose.Schema.Types.ObjectId,
    // ref: 'Setlist'
    type: String,
    required: false
  }]
}, { versionKey: false, collection: 'users' }); 

const User = mongoose.model('User', userSchema);

export default User;