import mongoose from 'mongoose';

const songSchema = new mongoose.Schema({
  songTitle: {
    type: String,
    required: true
  },
  artistIDs: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Artist',  
    required: true
  }],
  audio: {
    type: String,
    required: true
  },
  lyrics: {
    type: String,
    required: true
  }
}, { versionKey: false, collection: 'song' });  

const Song = mongoose.model('Song', songSchema);

export default Song;