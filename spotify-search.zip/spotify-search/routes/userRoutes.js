import express from 'express';
import User from '../models/userModel.js';

import Setlist from '../models/setlistModel.js';

import mongoose from 'mongoose';

const router = express.Router();

// GET users 
router.get('/', async (req, res) => {
    try {
        const users = await User.find().populate('favoriteSetlists');
        res.json(users);
    } catch (error) {
        res.status(500).json({ message: 'Error fetching users', error: error.message });
    }
});


router.post('/', async (req, res) => {
    const { email, name, password, favoriteSetlists } = req.body;

    try {
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ message: 'User with this email already exists' });
        }

        const newUser = new User({
            email,
            name,
            password, 
            favoriteSetlists
        });

        await newUser.save();

        res.status(201).json({ message: 'User registered successfully', userId: newUser._id });
    } catch (error) {
        console.error('Error adding user:', error.message);
        res.status(500).json({ message: 'Server error', error: error.message });
    }
});


router.post('/login', async (req, res) => {
    const { email, password } = req.body;

    try {
        
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(400).json({ message: 'Invalid email or password' });
        }

       
        if (user.password !== password) {
            return res.status(400).json({ message: 'Invalid email or password' });
        }

        
        res.status(200).json({ 
            message: 'Login successful', 
            userId: user._id, 
            name: user.name, 
            email: user.email 
        });
    } catch (error) {
        console.error('Login error:', error.message);
        res.status(500).json({ message: 'Server error', error: error.message });
    }
});



router.get('/:id', async (req, res) => {
    
    try {
        const user = await User.findById(req.params.id).populate('favoriteSetlists');
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

   
        res.json({
            _id: user._id,
            name: user.name,
            email: user.email,
            password: user.password, 
            favoriteSetlists: user.favoriteSetlists
        });
    } catch (error) {
        res.status(500).json({ message: 'Error fetching user', error: error.message });
    }
});



router.get('/:id/favoriteSetlists', async (req, res) => {
    try {
      const userId = req.params.id;
  
      const user = await User.findById(userId);
  
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
  
      return res.status(200).json({ favoriteSetlists: user.favoriteSetlists });
    } catch (error) {
      console.error(error);
      return res.status(500).json({ message: 'Server error' });
    }
  });




export default router;