import express from 'express';
import Artist from '../models/artistModel.js'; 


const router = express.Router();


//GET artists 
    router.get('/', async (req, res) => {
    // console.log('Fetching all artists from MongoDB...');
    
    try {
        const artists = await Artist.find(); 
        // console.log('Artists found:', artists);
        
        res.json(artists); 
    } catch (error) {
        console.error('Error fetching artists:', error.message);
        res.status(500).json({ message: 'Server error', error: error.message });
    }
});

//PUT update artist 
router.put('/:id', async (req, res) => {
    console.log('PUT request received for:', req.params.id);
    console.log('Request body:', req.body);
    try {
        const { artistName, artistImage } = req.body;
        const updatedArtist = await Artist.findByIdAndUpdate(
            req.params.id,
            { artistName, artistImage },
            { new: true, runValidators: true }
        );

        if (!updatedArtist) {
            return res.status(404).json({ message: 'Artist not found' });
        }

        res.json(updatedArtist);
    } catch (error) {
        console.error('Error updating artist:', error.message);
        res.status(500).json({ message: 'Server error', error: error.message });
    }
});

//POST add artist 
router.post('/', async (req, res) => {
    try {
        const { artistName, artistImage } = req.body;

        if (!artistName) {
            return res.status(400).json({ message: 'Artist name is required' });
        }

        const newArtist = new Artist({
            artistName,
            artistImage: artistImage || '' 
        });

        await newArtist.save();
        res.status(201).json(newArtist);
    } catch (error) {
        console.error('Error adding artist:', error.message);
        res.status(500).json({ message: 'Server error', error: error.message });
    }
});

router.get('/:id', async (req, res) => {
    try {
        const artist = await Artist.findById(req.params.id);
        if (!artist) {
            return res.status(404).json({ message: 'Artist not found' });
        }
        res.json(artist); 
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error fetching artist data' });
    }
});


router.get('/name/:artistName', async (req, res) => {
    try {
        const artist = await Artist.findOne({ artistName: req.params.artistName });
        
        if (!artist) {
            return res.status(404).json({ message: 'Artist not found' });
        }

        res.json(artist);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error fetching artist data', error: err.message });
    }
});




router.post('/getOrCreate', async (req, res) => {
    const { name } = req.body;
    try {
      let artist = await Artist.findOne({ artistName: name }); 
      if (!artist) {
        artist = new Artist({
          artistName: name,
          artistImage: "image.jpg" 
        });
        await artist.save();
      }
      res.json({ artistId: artist._id });
    } catch (err) {
      res.status(500).json({ error: 'Failed to get or create artist' });
    }
  });







export default router;

