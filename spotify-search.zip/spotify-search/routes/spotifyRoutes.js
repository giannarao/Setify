import express from 'express';  
import { 
    searchArtist, 
    searchSong, 
    searchSongWithArtist, 
    searchArtistSongs,
    createArtist
} from '../controllers/spotifyController.js'; 

const router = express.Router();

router.get('/search-artist', searchArtist);                  // search for artist 
router.get('/search-song', searchSong);                      // search for song 
router.get('/search-song-with-artist', searchSongWithArtist);  // search for song, get artists 
router.get('/search-artist-songs', searchArtistSongs);         // search for artist, get songs 

router.put('/create-artist', createArtist); // add artist 

//put 


export default router;





