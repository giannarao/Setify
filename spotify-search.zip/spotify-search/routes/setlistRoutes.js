import express from 'express';
import mongoose from 'mongoose';
import Setlist from '../models/setlistModel.js';
import User from '../models/userModel.js';

const { ObjectId } = mongoose.Types;
const router = express.Router();


// GET all setlists
router.get('/', async (req, res) => {
  try {
    const setlists = await Setlist.find();
    res.json(setlists);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching setlists', error: error.message });
  }
});

// POST a new setlist
router.post('/', async (req, res) => {
  const {
    setlistName,
    setlistImage,
    createdBy,
    tourName,
    headlinerName,
    date_location,
    openerNames,
    headlinerSongIDs
  } = req.body;

  try {
    const openerNamesWithObjectId = openerNames.map(opener => ({
      name: opener.name, 
      songs: opener.songs 
    }));

    if (date_location) {
      date_location.forEach(location => delete location._id);
    }

    if (openerNamesWithObjectId) {
      openerNamesWithObjectId.forEach(opener => delete opener._id);
    }

    const newSetlist = new Setlist({
      setlistName,
      setlistImage,
      createdBy,
      tourName,
      headlinerName,
      date_location,
      openerNames: openerNamesWithObjectId,
      headlinerSongIDs
    });

    await newSetlist.save();
    res.status(201).json(newSetlist);
  } catch (error) {
    console.error('Error adding setlist:', error.message);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// GET all setlists with artist and song names
router.get('/with-artists', async (req, res) => {
  try {
    const setlists = await Setlist.aggregate([
      {
        $lookup: {
          from: 'artist',
          localField: 'headlinerName',
          foreignField: '_id',
          as: 'actualArtistNames'
        }
      },
      {
        $lookup: {
          from: 'artist',
          localField: 'openerNames.name',
          foreignField: '_id',
          as: 'actualOpenerNames'
        }
      },
      {
        $lookup: {
          from: 'song',
          localField: 'headlinerSongIDs',
          foreignField: '_id',
          as: 'actualHeadlinerSongNames'
        }
      },
      {
        $lookup: {
          from: 'song',
          localField: 'openerNames.songs',
          foreignField: '_id',
          as: 'actualOpenerSongNames'
        }
      },
      {
        $project: {
          _id: 1,
          setlistName: 1,
          setlistImage: 1,
          createdBy: 1,
          tourName: 1,
          headlinerName: 1,
          date_location: 1,
          openerNames: 1,
          headlinerSongIDs: 1,
          actualArtistNames: {
            $map: {
              input: "$actualArtistNames",
              as: "artist",
              in: "$$artist.artistName"
            }
          },
          actualOpenerNames: {
            $map: {
              input: "$actualOpenerNames",
              as: "opener",
              in: "$$opener.artistName"
            }
          },
          actualHeadlinerSongNames: {
            $map: {
              input: "$actualHeadlinerSongNames",
              as: "song",
              in: "$$song.songTitle"
            }
          },
          actualOpenerSongNames: {
            $map: {
              input: "$actualOpenerSongNames",
              as: "song",
              in: "$$song.songTitle"
            }
          }
        }
      }
    ]);

    res.json(setlists);
  } catch (err) {
    console.error('Error fetching setlists:', err);
    res.status(500).send('Error fetching setlists');
  }
});

// GET setlist by ID with populated names
router.get('/:id', async (req, res) => {
  const { id } = req.params;

  try {
    const setlist = await Setlist.aggregate([
      {
        $match: { _id: new ObjectId(id) }
      },
      {
        $lookup: {
          from: 'artist',
          localField: 'headlinerName',
          foreignField: '_id',
          as: 'actualArtistNames'
        }
      },
      {
        $lookup: {
          from: 'artist',
          localField: 'openerNames.name',
          foreignField: '_id',
          as: 'actualOpenerNames'
        }
      },
      {
        $lookup: {
          from: 'song',
          localField: 'headlinerSongIDs',
          foreignField: '_id',
          as: 'actualHeadlinerSongNames'
        }
      },
      {
        $lookup: {
          from: 'song',
          localField: 'openerNames.songs',
          foreignField: '_id',
          as: 'actualOpenerSongNames'
        }
      },
      {
        $project: {
          _id: 1,
          setlistName: 1,
          setlistImage: 1,
          createdBy: 1,
          tourName: 1,
          headlinerName: 1,
          date_location: 1,
          openerNames: 1,
          headlinerSongIDs: 1,
          actualArtistNames: {
            $map: {
              input: "$actualArtistNames",
              as: "artist",
              in: "$$artist.artistName"
            }
          },
          actualOpenerNames: {
            $map: {
              input: "$actualOpenerNames",
              as: "opener",
              in: "$$opener.artistName"
            }
          },
          actualHeadlinerSongNames: {
            $map: {
              input: "$actualHeadlinerSongNames",
              as: "song",
              in: "$$song.songTitle"
            }
          },
          actualOpenerSongNames: {
            $map: {
              input: "$actualOpenerSongNames",
              as: "song",
              in: "$$song.songTitle"
            }
          }
        }
      }
    ]);

    if (!setlist || setlist.length === 0) {
      return res.status(404).json({ message: 'Setlist not found' });
    }

    res.json(setlist[0]);
  } catch (err) {
    console.error('Error fetching setlist by ID:', err);
    res.status(500).json({ message: 'Error fetching setlist by ID', error: err.message });
  }
});

// GET setlists by user ID
router.get('/user/:userId', async (req, res) => {
  const { userId } = req.params;

  try {
    const setlists = await Setlist.aggregate([
      {
        $match: {
          createdBy: new ObjectId(userId)
        }
      },
      {
        $lookup: {
          from: 'artist',
          localField: 'headlinerName',
          foreignField: '_id',
          as: 'actualArtistNames'
        }
      },
      {
        $lookup: {
          from: 'artist',
          localField: 'openerNames.name',
          foreignField: '_id',
          as: 'actualOpenerNames'
        }
      },
      {
        $lookup: {
          from: 'song',
          localField: 'headlinerSongIDs',
          foreignField: '_id',
          as: 'actualHeadlinerSongNames'
        }
      },
      {
        $lookup: {
          from: 'song',
          localField: 'openerNames.songs',
          foreignField: '_id',
          as: 'actualOpenerSongNames'
        }
      },
      {
        $project: {
          _id: 1,
          setlistName: 1,
          setlistImage: 1,
          createdBy: 1,
          tourName: 1,
          headlinerName: 1,
          date_location: 1,
          openerNames: 1,
          headlinerSongIDs: 1,
          actualArtistNames: {
            $map: {
              input: "$actualArtistNames",
              as: "artist",
              in: "$$artist.artistName"
            }
          },
          actualOpenerNames: {
            $map: {
              input: "$actualOpenerNames",
              as: "opener",
              in: "$$opener.artistName"
            }
          },
          actualHeadlinerSongNames: {
            $map: {
              input: "$actualHeadlinerSongNames",
              as: "song",
              in: "$$song.songTitle"
            }
          },
          actualOpenerSongNames: {
            $map: {
              input: "$actualOpenerSongNames",
              as: "song",
              in: "$$song.songTitle"
            }
          }
        }
      }
    ]);

    res.json(setlists);
  } catch (err) {
    console.error('Error fetching setlists by user ID:', err);
    res.status(500).json({ message: 'Error fetching setlists by user ID', error: err.message });
  }
});


router.put('/:id/favorite', async (req, res) => {

const { favoriteStatus, userId } = req.body;

  try {
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    const setlistId = req.params.id;

    const setlistObjectId = new mongoose.Types.ObjectId(setlistId);

    const favoriteSetlists = user.favoriteSetlists.map(id => new mongoose.Types.ObjectId(id));

    if (favoriteStatus) {
      if (!favoriteSetlists.some(id => id.equals(setlistObjectId))) {
        user.favoriteSetlists.push(setlistObjectId);
      }
    } else {
      user.favoriteSetlists = user.favoriteSetlists.filter(
        (id) => !new mongoose.Types.ObjectId(id).equals(setlistObjectId)
      );
    }

    await user.save();
    return res.status(200).json({
      message: "Favorite setlist updated",
      favoriteSetlists: user.favoriteSetlists,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Internal server error" });
  }
});


export default router;