import express from 'express';
import Song from '../models/songModel.js';


import Artist from '../models/artistModel.js';



const router = express.Router();

// GET songs
router.get('/', async (req, res) => {
    try {
        const songs = await Song.find().populate('artistIDs');
        res.json(songs);
    } catch (error) {
        res.status(500).json({ message: 'Error fetching songs', error: error.message });
    }
});

//POST add song 
router.post('/', async (req, res) => {
    const { songTitle, artistIDs, audio, lyrics } = req.body;

    try {
        const newSong = new Song({
            songTitle,
            artistIDs,
            audio,
            lyrics
        });

        await newSong.save();

        res.status(201).json(newSong);
    } catch (error) {
        res.status(500).json({ message: 'Server error', error: error.message });
    }
});





router.post('/getOrAddSong', async (req, res) => {
  const { songTitle, artistName } = req.body;

  if (!songTitle || !artistName) {
      return res.status(400).json({ message: 'Missing songTitle or artistName' });
  }

  try {
      const artist = await Artist.findOne({ artistName });

      if (!artist) {
          return res.status(404).json({ message: `Artist not found: ${artistName}` });
      }

      const existingSong = await Song.findOne({
          songTitle,
          artistIDs: artist._id
      });

      if (existingSong) {
          return res.status(200).json(existingSong);
      }

      const encodedSong = encodeURIComponent(`${songTitle} ${artistName}`);
      const audio = `https://www.youtube.com/results?search_query=${encodedSong}`;
      const lyrics = `https://www.google.com/search?q=${encodedSong}+lyrics`;

      const newSong = new Song({
          songTitle,
          artistIDs: [artist._id],
          audio,
          lyrics
      });

      await newSong.save();
      return res.status(201).json(newSong);
  } catch (error) {
      console.error('Error in getOrAddSong:', error.message);
      return res.status(500).json({ message: 'Server error', error: error.message });
  }
});



//get by title 
router.get('/title/:songTitle', async (req, res) => {
  try {
    const songTitle = req.params.songTitle;

    const song = await Song.findOne({ songTitle }).populate('artistIDs');

    if (!song) {
        return res.status(404).json({ error: 'Song not found' });
    }

    res.json(song);
} catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
}
});




//get by id 
router.get('/:id', async (req, res) => {
    try {
      const songId = req.params.id;
  
      const song = await Song.findById(songId);
  
      if (!song) {
        return res.status(404).json({ error: 'Song not found' });
      }
  
      res.json(song);
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: 'Server error' });
    }
  });



export default router;