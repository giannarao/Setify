/* global use, db */
// MongoDB Playground
// To disable this template go to Settings | MongoDB | Use Default Template For Playground.
// Make sure you are connected to enable completions and to be able to run a playground.
// Use Ctrl+Space inside a snippet or a string literal to trigger completions.
// The result of the last command run in a playground is shown on the results panel.
// By default the first 20 documents will be returned with a cursor.
// Use 'console.log()' to print to the debug output.
// For more documentation on playgrounds please refer to
// https://www.mongodb.com/docs/mongodb-vscode/playgrounds/





use('honorsProject1');

//artist names 
console.log("Artists:")
db.getCollection('artist').find().forEach(doc => {
  console.log(doc.artistName);  
});




//song titles 
console.log('\n'); 
console.log("Songs:")
db.getCollection('song').find().forEach(doc => {
  console.log(doc.songTitle);  
});




//all songs by a certain artist 
const artist = db.getCollection('artist').findOne({ artistName: 'Kelsea Ballerini' }); 
console.log('\n'); 
console.log("Songs by a certain artist:")
if (artist) {
  db.getCollection('song').find({ artistIDs: artist._id }).forEach(doc => {
    console.log (doc.songTitle);  
  });
} else {
  console.log('Artist not found');
}




//search for setlist by artist name 
console.log('\n');
console.log("Setlists by artist:");
const headlinerName = "Kelsea Ballerini";
db.getCollection('setlist').find({ headlinerName: headlinerName }).forEach(doc => {
  console.log('Setlist Name: '+ doc.setlistName, 'City: ' + doc.date_location[0].city);
});




//search for setlist with date 
//why is date showing 2-3 not 2-4? 
const searchDate = new Date('2025-02-04'); 
console.log('\nSetlists on ' + searchDate.toDateString() + ':');
db.getCollection('setlist').find({
  'date_location.date': { $eq: searchDate }
}).forEach(doc => {
  console.log("Setlist name: " + doc.setlistName, "City: " + doc.date_location[0].city);
}); 


//search for setlist with tour name 
const tourName = "Patterns Tour";
console.log('\nSetlists for tour: ' + tourName);
db.getCollection('setlist').find({
  tourName: { $eq: tourName }
}).forEach(doc => {
  console.log("Setlist name: " + doc.setlistName, "Date: " + doc.date_location[0].date);
});
















// // Select the database to use.
// use('mongodbVSCodePlaygroundDB');

// // Insert a few documents into the sales collection.
// db.getCollection('sales').insertMany([
//   { 'item': 'abc', 'price': 10, 'quantity': 2, 'date': new Date('2014-03-01T08:00:00Z') },
//   { 'item': 'jkl', 'price': 20, 'quantity': 1, 'date': new Date('2014-03-01T09:00:00Z') },
//   { 'item': 'xyz', 'price': 5, 'quantity': 10, 'date': new Date('2014-03-15T09:00:00Z') },
//   { 'item': 'xyz', 'price': 5, 'quantity': 20, 'date': new Date('2014-04-04T11:21:39.736Z') },
//   { 'item': 'abc', 'price': 10, 'quantity': 10, 'date': new Date('2014-04-04T21:23:13.331Z') },
//   { 'item': 'def', 'price': 7.5, 'quantity': 5, 'date': new Date('2015-06-04T05:08:13Z') },
//   { 'item': 'def', 'price': 7.5, 'quantity': 10, 'date': new Date('2015-09-10T08:43:00Z') },
//   { 'item': 'abc', 'price': 10, 'quantity': 5, 'date': new Date('2016-02-06T20:20:13Z') },
// ]);

// // Run a find command to view items sold on April 4th, 2014.
// const salesOnApril4th = db.getCollection('sales').find({
//   date: { $gte: new Date('2014-04-04'), $lt: new Date('2014-04-05') }
// }).count();

// // Print a message to the output window.
// console.log(`${salesOnApril4th} sales occurred in 2014.`);

// // Here we run an aggregation and open a cursor to the results.
// // Use '.toArray()' to exhaust the cursor to return the whole result set.
// // You can use '.hasNext()/.next()' to iterate through the cursor page by page.
// db.getCollection('sales').aggregate([
//   // Find all of the sales that occurred in 2014.
//   { $match: { date: { $gte: new Date('2014-01-01'), $lt: new Date('2015-01-01') } } },
//   // Group the total sales for each product.
//   { $group: { _id: '$item', totalSaleAmount: { $sum: { $multiply: [ '$price', '$quantity' ] } } } }
// ]);

