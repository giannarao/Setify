import Setlist from "../models/setlistModel";

async function aggregateWithMongoDB(){
    
}