import axios from 'axios';  


import Artist from '../models/artistModel.js'; 


let accessToken = '';  

async function getAccessToken() {
    const response = await axios.post(
        'https://accounts.spotify.com/api/token',
        new URLSearchParams({ grant_type: 'client_credentials' }),
        {
            headers: {
                Authorization: `Basic ${Buffer.from(
                    `${process.env.SPOTIFY_CLIENT_ID}:${process.env.SPOTIFY_CLIENT_SECRET}`
                ).toString('base64')}`,
                'Content-Type': 'application/x-www-form-urlencoded',
            },
        }
    );
    accessToken = response.data.access_token;
}





export const createArtist = async (req, res) => {
    try {
        console.log("creating artist method")
        //console.log(req)
        const { artistName, artistImage } = req.body;

        if (!artistName || !artistImage) {
            return res.status(400).json({ error: 'Both artistName and artistImage are required' });
        }

        const newArtist = new Artist({ artistName, artistImage });
        //console.log(newArtist)
        //await newArtist.save();

        res.status(201).json(newArtist);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};





//search for artist 
export const searchArtist = async (req, res) => {
    const artistName = req.query.artist;
    if (!artistName) {
        return res.status(400).json({ error: 'Artist name is required' });
    }

    if (!accessToken) await getAccessToken();

    try {
        const response = await axios.get(
            `https://api.spotify.com/v1/search?q=${encodeURIComponent(artistName)}&type=artist`,
            { headers: { Authorization: `Bearer ${accessToken}` } }
        );

        const artistNames = response.data.artists.items.map(artist => artist.name);

        res.json(artistNames); 
    } catch (error) {
        res.status(500).json({ error: 'Error fetching data from Spotify' });
    }
};

//search for song 
export const searchSong = async (req, res) => {
    const songTitle = req.query.song;
    if (!songTitle) {
        return res.status(400).json({ error: 'Song title is required' });
    }

    if (!accessToken) await getAccessToken();

    try {
        const response = await axios.get(
            `https://api.spotify.com/v1/search?q=${encodeURIComponent(songTitle)}&type=track`,
            { headers: { Authorization: `Bearer ${accessToken}` } }
        );

        const songTitles = response.data.tracks.items.map(track => track.name);

        res.json(songTitles); 
    } catch (error) {
        res.status(500).json({ error: 'Error fetching data from Spotify' });
    }
};

//search for song, get artists who have that song 
export const searchSongWithArtist = async (req, res) => {
    const songTitle = req.query.song;
    if (!songTitle) {
        return res.status(400).json({ error: 'Song title is required' });
    }

    if (!accessToken) await getAccessToken();

    try {
        const response = await axios.get(
            `https://api.spotify.com/v1/search?q=${encodeURIComponent(songTitle)}&type=track`,
            { headers: { Authorization: `Bearer ${accessToken}` } }
        );

        const songsWithArtists = response.data.tracks.items.map(track => ({
            song: track.name,
            artist: track.artists.map(artist => artist.name).join(', ') 
        }));

        res.json(songsWithArtists);  
    } catch (error) {
        res.status(500).json({ error: 'Error fetching data from Spotify' });
    }
};

//search for artist, get songs by that artist 
export const searchArtistSongs = async (req, res) => {
    const artistName = req.query.artist;
    if (!artistName) {
        return res.status(400).json({ error: 'Artist name is required' });
    }

    if (!accessToken) await getAccessToken();

    try {
        const artistResponse = await axios.get(
            `https://api.spotify.com/v1/search?q=${encodeURIComponent(artistName)}&type=artist`,
            { headers: { Authorization: `Bearer ${accessToken}` } }
        );

        if (artistResponse.data.artists.items.length === 0) {
            return res.status(404).json({ error: 'Artist not found' });
        }

        const artistId = artistResponse.data.artists.items[0].id;

        const tracksResponse = await axios.get(
            `https://api.spotify.com/v1/artists/${artistId}/top-tracks?market=US`,
            { headers: { Authorization: `Bearer ${accessToken}` } }
        );

        const results = tracksResponse.data.tracks.map(track => ({
            title: track.name,
            artist: artistResponse.data.artists.items[0].name
        }));

        res.json(results); 
    } catch (error) {
        res.status(500).json({ error: 'Error fetching data from Spotify' });
    }
};