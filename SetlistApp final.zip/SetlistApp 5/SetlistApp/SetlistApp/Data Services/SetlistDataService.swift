//
//  SetlistDataService.swift
//  SetlistApp
//
//  Created by Student on 3/26/25.
//

import Foundation

extension Notification.Name {
    static let didFetchSetlistById = Notification.Name("didFetchSetlistById")
    static let didFetchSetlistsByUser = Notification.Name("didFetchSetlistsByUser")
}


class SetlistDataService {
    
    static let shared = SetlistDataService()
    
//    private let baseURL = "http://localhost:3000/api/setlists"
    private let baseURL = "http://10.71.40.198:3000/api/setlists"
    
    
    func fetchSetlists() {
        guard let url = URL(string: baseURL) else {
            print("Invalid URL")
            return
        }
        
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                print("Error fetching data: \(error.localizedDescription)")
                return
            }
            
            guard let data = data else {
                print("No data received from server.")
                return
            }
            
            if let jsonString = String(data: data, encoding: .utf8) {
//                print("Raw JSON Setlists: \(jsonString)\n")
            }
            
            do {
                let decoder = JSONDecoder()
                let setlists = try decoder.decode([Setlist].self, from: data)
                
                DispatchQueue.main.async {
                    NotificationCenter.default.post(name: .didFetchSetlists, object: setlists)
                }
                
                for setlist in setlists {
//                    print("Setlist ID: \(setlist.id)")
//                    print("Setlist Name: \(setlist.setlistName)")
//                    print("Setlist Image: \(setlist.setlistImage ?? "No image")")
//                    print("Created By: \(setlist.createdBy)")
//                    print("Tour Name: \(setlist.tourName)")
//                    print("Headliner Name: \(setlist.headlinerName)")
//
                    for dateLocation in setlist.dateLocation {
//                        print("Date: \(dateLocation.date)")
//                        print("City: \(dateLocation.city)")
                    }
                    
                    
//                    print("Opener Names (Song IDs): \(setlist.openerNames)")
                    
                    
                    
//                    print("Headliner Song IDs: \(setlist.headlinerSongIDs)")
                    
//                    print("\n")
                }
            } catch {
                print("Error decoding setlist data: \(error.localizedDescription)")
            }
        }
        
        task.resume()
    }
    
    
    
    
    
    
    func fetchSetlistsWithArtistNames() {
        
        guard let url = URL(string: baseURL + "/with-artists") else { return }
        
        URLSession.shared.dataTask(with: url) { data, response, error in
                if let error = error {
                    print("Error fetching setlists: \(error)")
                    return
                }
                
                if let data = data {
                    
                    if let jsonString = String(data: data, encoding: .utf8) {
//                        print("Raw response data: \(jsonString)")
                    }
                    
                    do {
                        
                        let setlists = try JSONDecoder().decode([SetlistUploadDTO].self, from: data)
                        
                        NotificationCenter.default.post(name: .didFetchSetlists, object: setlists)
                    } catch {
                        
                        print("Error decoding setlists: \(error)")
                        
                        if let error = error as? DecodingError {
                            switch error {
                            case .typeMismatch(let type, let context):
                                print("Type mismatch error. Expected type: \(type), but found: \(context.debugDescription)")
                                print("Coding path leading to error: \(context.codingPath)")
                            default:
                                print("Decoding error: \(error)")
                            }
                        }
                    }
                }
            }.resume()
        }
    
    
    
    
  
        
    
    
    
    
    
    
    
         
    
    
    func addSetlist(setlist: Setlist, openerSongs: [String: [String]], completion: @escaping (Bool, Error?) -> Void) {
        let urlString = "\(baseURL)"
        guard let url = URL(string: urlString) else {
            print("Invalid URL")
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        var openers: [SetlistUploadDTO.Opener] = []
        for openerId in setlist.openerNames {
            if let songs = openerSongs[openerId] {
                let opener = SetlistUploadDTO.Opener(
                    name: openerId,
                    songs: songs
                )
                openers.append(opener)
            }
        }

        var dateLocationArray: [SetlistUploadDTO.DateLocation] = []
        for dateLocation in setlist.dateLocation {
            let dateLoc = SetlistUploadDTO.DateLocation(
                date: dateLocation.date,
                city: dateLocation.city
            )
            dateLocationArray.append(dateLoc)
        }

        let dto = SetlistUploadDTO(
            _id: "",
            date_location: dateLocationArray,
            setlistName: setlist.setlistName,
            setlistImage: setlist.setlistImage ?? "",
            createdBy: setlist.createdBy,
            tourName: setlist.tourName,
            headlinerName: setlist.headlinerName,
            openerNames: openers,
            headlinerSongIDs: setlist.headlinerSongIDs,
            actualArtistNames: setlist.actualArtistNames,
            actualOpenerNames: setlist.actualOpenerNames ?? [],
            actualHeadlinerSongNames: setlist.actualHeadlinerSongNames ?? [],
            actualOpenerSongNames: setlist.actualOpenerSongNames ?? []
        )

        do {
            let jsonData = try JSONEncoder().encode(dto)

            // Debugging: print the request body as JSON
            if let jsonString = String(data: jsonData, encoding: .utf8) {
//                print("Request JSON: \(jsonString)")
            }

            request.httpBody = jsonData
        } catch {
            completion(false, error)
            return
        }

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                completion(false, error)
                return
            }

            // Debugging: print the raw response from the server
            if let data = data, let rawResponse = String(data: data, encoding: .utf8) {
//                print("Raw server response: \(rawResponse)")
            }

            // Check if the response is successful
            if let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 201 {
                completion(true, nil)
            } else {
                completion(false, nil)
            }
        }

        task.resume()
    }
    
    
    
     


    func fetchSetlistById(id: String, completion: @escaping (Result<SetlistUploadDTO, Error>) -> Void) {
        
        let urlString = "\(baseURL)/\(id)"
        
                guard let url = URL(string: urlString) else {
                            print("Invalid URL")
                            return
                        }
        
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            
            guard let data = data else {
                completion(.failure(NSError(domain: "No data received", code: 0, userInfo: nil)))
                return
            }
            
            do {
                let decoder = JSONDecoder()
                let setlist = try decoder.decode(SetlistUploadDTO.self, from: data)
                completion(.success(setlist))
            } catch {
                completion(.failure(error))
            }
        }
        
        task.resume()
    }
    
    
    
    func fetchSetlistsByUser(userId: String) {
        
        guard let url = URL(string: baseURL + "/user/\(userId)") else {
            print("Invalid URL")
            return
        }

        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                print("Error fetching setlists by user ID: \(error.localizedDescription)")
                return
            }

            guard let data = data else {
                print("No data received from server.")
                return
            }

            if let jsonString = String(data: data, encoding: .utf8) {
//                print("Raw JSON for user \(userId):\n\(jsonString)")
            }

            do {
                let decoder = JSONDecoder()
                let setlists = try decoder.decode([SetlistUploadDTO].self, from: data)

                DispatchQueue.main.async {
                    NotificationCenter.default.post(name: .didFetchSetlistsByUser, object: setlists)
                }
            } catch {
                print("Error decoding user setlist data: \(error)")
                if let decodingError = error as? DecodingError {
                    switch decodingError {
                    case .typeMismatch(let type, let context):
                        print("Type mismatch for type \(type) at \(context.codingPath): \(context.debugDescription)")
                    case .valueNotFound(let type, let context):
                        print("Value not found for type \(type) at \(context.codingPath): \(context.debugDescription)")
                    case .keyNotFound(let key, let context):
                        print("Key not found: \(key.stringValue) at \(context.codingPath): \(context.debugDescription)")
                    case .dataCorrupted(let context):
                        print("Data corrupted at \(context.codingPath): \(context.debugDescription)")
                    @unknown default:
                        print("Unknown decoding error")
                    }
                }
            }
        }

        task.resume()
    }
    
    
    func updateFavoriteSetlist(setlistId: String, userId: String, favoriteStatus: Bool, completion: @escaping (Result<[String], Error>) -> Void) {
        
        guard let url = URL(string: "\(baseURL)/\(setlistId)/favorite") else {
                   completion(.failure(NSError(domain: "", code: 400, userInfo: [NSLocalizedDescriptionKey: "Invalid URL"])))
                   return
               }
               
               let parameters: [String: Any] = [
                   "favoriteStatus": favoriteStatus,
                   "userId": userId
               ]
               
               guard let jsonData = try? JSONSerialization.data(withJSONObject: parameters, options: []) else {
                   completion(.failure(NSError(domain: "", code: 400, userInfo: [NSLocalizedDescriptionKey: "Invalid parameters"])))
                   return
               }
               
               var request = URLRequest(url: url)
               request.httpMethod = "PUT"
               request.setValue("application/json", forHTTPHeaderField: "Content-Type")
               request.httpBody = jsonData
               
               let task = URLSession.shared.dataTask(with: request) { data, response, error in
                   
                   if let error = error {
                       print("Request error: \(error.localizedDescription)")
                       completion(.failure(error))
                       return
                   }
                   
                   guard let data = data else {
                       completion(.failure(NSError(domain: "", code: 500, userInfo: [NSLocalizedDescriptionKey: "No data received"])))
                       return
                   }
                   
                   if let jsonString = String(data: data, encoding: .utf8) {
//                       print("Raw response data: \(jsonString)")
                   }
                   
                   do {
                       let decodedResponse = try JSONDecoder().decode(FavoriteSetlistResponse.self, from: data)
                       
//                       print("Decoded response: \(decodedResponse)")
                       
                       completion(.success(decodedResponse.favoriteSetlists ?? []))
                   } catch {
                       print("Decoding error: \(error)")
                       
                       completion(.failure(error))
                   }
               }
               
               task.resume()
           }
    
    
}

