//
//  APIVar.swift
//  SetlistApp
//
//  Created by Student on 3/26/25.
//

import Foundation

class ApiVar {
    static let apiString = "http://localhost:3000/api"
}

