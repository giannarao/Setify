//
//  SongDataService.swift
//  SetlistApp
//
//  Created by Student on 3/26/25.
//

import Foundation

class SongDataService {
    static let shared = SongDataService()
    
//    private let baseURL = "http://localhost:3000/api/songs"
    private let baseURL = "http://10.71.40.198:3000/api/songs"
    
    func fetchSongs() {
        guard let url = URL(string: baseURL) else {
            print("Invalid URL")
            return
        }
        
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                print("Error fetching song data: \(error.localizedDescription)")
                return
            }
            
            guard let data = data else {
                print("No data received from the server.")
                return
            }
            
            do {
                let decoder = JSONDecoder()
                let songs = try decoder.decode([Song].self, from: data)
                
                for song in songs {
//                    print("Song Title: \(song.songTitle)")
                    
                    for artistID in song.artistIDs {
                        
                        ArtistDataService.shared.fetchArtistByID(artistID: artistID) { artist in
                            if let artist = artist {
//                                print("Artist Name: \(artist.artistName)")
//                                print("Artist Image: \(artist.artistImage ?? "No image available")\n")
                            }
                        }
                    }
                }
            } catch {
                print("Error decoding song data: \(error.localizedDescription)")
            }
        }
        
        task.resume()
    }
    
    
    
    
    
   
    
    func fetchSongByID(songId: String, completion: @escaping (Song?) -> Void) {
            guard let url = URL(string: "\(baseURL)/\(songId)") else {
                print("Invalid URL")
                completion(nil)
                return
            }
            
            let task = URLSession.shared.dataTask(with: url) { data, response, error in
              
                if let error = error {
                    print("Error fetching song data: \(error)")
                    completion(nil)
                    return
                }
                
                guard let data = data else {
                    print("No data received")
                    completion(nil)
                    return
                }

                do {
                    let song = try JSONDecoder().decode(Song.self, from: data)
                    completion(song)
                } catch {
                    print("Error decoding song data: \(error)")
                    completion(nil)
                }
            }
            task.resume()
        }
        
       
    
    
    
     
    
    
    func fetchSongByTitleDTO(songTitle: String, completion: @escaping (SongModelUploadDTO?) -> Void) {
            let urlString = "\(baseURL)/title/\(songTitle)"
                    
            guard let url = URL(string: urlString) else {
                print("Invalid URL: \(urlString)")
                completion(nil)
                return
            }
            
            URLSession.shared.dataTask(with: url) { data, response, error in
                if let error = error {
                    print("Error fetching song details: \(error.localizedDescription)")
                    completion(nil)
                    return
                }
                
                guard let data = data else {
                    print("No data received from the API.")
                    completion(nil)
                    return
                }
                
                if let jsonString = String(data: data, encoding: .utf8) {
//                    print("Raw Response: \(jsonString)")
                }

                do {
                    let song = try JSONDecoder().decode(SongModelUploadDTO.self, from: data)
                    completion(song)
                } catch {
                    print("Error decoding song data: \(error.localizedDescription)")
                    completion(nil)
                }
            }.resume()
        }
        
    func fetchSongByTitle(songTitle: String, completion: @escaping (Song?) -> Void) {
        let encodedTitle = songTitle.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? songTitle
        let urlString = "\(baseURL)/title/\(encodedTitle)"
        
        guard let url = URL(string: urlString) else {
            print("Invalid URL: \(urlString)")
            completion(nil)
            return
        }
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                print("Error fetching song details: \(error.localizedDescription)")
                completion(nil)
                return
            }
            
            guard let data = data else {
                print("No data received from the API.")
                completion(nil)
                return
            }
            
            if let jsonString = String(data: data, encoding: .utf8) {
//                print("Raw Response: \(jsonString)")
            }
            
            do {
                let dto = try JSONDecoder().decode(SongModelUploadDTO.self, from: data)
                
                let artistIDs = dto.artistIDs.map { $0.id }
                
                let song = Song(
                    id: dto.id,
                    songTitle: dto.songTitle,
                    artistIDs: artistIDs,
                    audio: dto.audio,
                    lyrics: dto.lyrics
                )
                
                completion(song)
            } catch {
                print("Error decoding song data: \(error.localizedDescription)")
                completion(nil)
            }
        }.resume()
    }
    
    
    
    
    
    
    
    
    
    func getOrAddSong(songTitle: String, artistName: String, completion: @escaping (Song?) -> Void) {
        
        guard let url = URL(string: "\(baseURL)/getOrAddSong") else {
            print("Invalid URL")
            completion(nil)
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let requestBody: [String: String] = [
            "songTitle": songTitle,
            "artistName": artistName
        ]
        
        do {
            request.httpBody = try JSONEncoder().encode(requestBody)
        } catch {
            print("Error encoding request body: \(error)")
            completion(nil)
            return
        }
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error calling getOrAddSong: \(error)")
                completion(nil)
                return
            }
            
            guard let data = data else {
                print("No data received from getOrAddSong")
                completion(nil)
                return
            }
            
            if let jsonString = String(data: data, encoding: .utf8) {
//                print("Raw getOrAddSong response: \(jsonString)")
                
                if jsonString.contains("Artist not found") {
                    print("Error: Artist not found")
                    completion(nil)
                    return
                }
            }
            
            do {
                let song = try JSONDecoder().decode(Song.self, from: data)
                completion(song)
            } catch {
                print("Error decoding song from getOrAddSong: \(error)")
                completion(nil)
            }
        }.resume()
        
        
        
        
        
    }
    
    
    
    
}
