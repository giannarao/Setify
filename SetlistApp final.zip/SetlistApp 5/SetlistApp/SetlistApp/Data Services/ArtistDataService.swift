//
//  ArtistDataService.swift
//  SetlistApp
//
//  Created by Student on 3/26/25.
//

import Foundation

class ArtistDataService {
    static let shared = ArtistDataService()
    
//    private let baseURL = "http://localhost:3000/api/artists"
    private let baseURL = "http://10.71.40.198:3000/api/artists"
    
    
    func fetchArtists() {
            guard let url = URL(string: baseURL) else {
                print("Invalid URL")
                return
            }
            
            let task = URLSession.shared.dataTask(with: url) { data, response, error in
                if let error = error {
                    print("Error fetching data: \(error.localizedDescription)")
                    return
                }
                
                guard let data = data else {
                    print("No data received from the server.")
                    return
                }
                
                do {
                    let decoder = JSONDecoder()
                    let artists = try decoder.decode([Artist].self, from: data)
                    
                    for artist in artists {
//                        print("Artist Name: \(artist.artistName)")
                        if let image = artist.artistImage {
//                            print("Artist Image: \(image)\n")
                        } else {
//                            print("No image available")
                        }
                    }
                } catch {
                    print("Error decoding artist data: \(error.localizedDescription)")
                }
            }
            
            task.resume()
        }
    
    
    func fetchArtistByID(artistID: String, completion: @escaping (Artist?) -> Void) {
        
        guard let url = URL(string: "\(baseURL)/\(artistID)") else {
                print("Invalid URL for fetching artist data")
                completion(nil)
                return
            }

            let task = URLSession.shared.dataTask(with: url) { data, response, error in
                if let error = error {
                    print("Error fetching artist: \(error.localizedDescription)")
                    completion(nil)
                    return
                }

                guard let data = data else {
                    print("No data returned from server")
                    completion(nil)
                    return
                }

                if let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode != 200 {
                    print("Error: Received HTTP status code \(httpResponse.statusCode)")
                    completion(nil)
                    return
                }

                if let rawString = String(data: data, encoding: .utf8) {
//                    print("Raw response data: \(rawString)")
                }

                do {
                    let artist = try JSONDecoder().decode(Artist.self, from: data)
                    completion(artist)
                } catch {
                    print("Error decoding artist data: \(error.localizedDescription)")
                    completion(nil)
                }
            }

            task.resume()
        }
        
    
    
    
    func fetchArtistByName(artistName: String, completion: @escaping (Artist?) -> Void) {
           
        guard let url = URL(string: "\(baseURL)/name/\(artistName)") else {
            print("Invalid URL for fetching artist data")
            completion(nil)
            return
        }
            
            let task = URLSession.shared.dataTask(with: url) { data, response, error in
                if let error = error {
                    print("Error: \(error.localizedDescription)")
                    completion(nil)
                    return
                }
                
                guard let data = data else {
                    print("No data received")
                    completion(nil)
                    return
                }

                if let rawString = String(data: data, encoding: .utf8) {
//                    print("Raw response data: \(rawString)")
                }
                
                do {
                    let decoder = JSONDecoder()
                    let artist = try decoder.decode(Artist.self, from: data)
                    completion(artist)
                } catch {
                    print("Decoding error: \(error.localizedDescription)")  
                    completion(nil)
                }
            }
            
            task.resume()
        }
    
    
    
    
    
    
    
    func addArtist(artistName: String, artistImage: String, completion: @escaping (Result<Artist, Error>) -> Void) {
        
        guard let url = URL(string: baseURL) else {
            print("Invalid URL")
            return
        }

            var request = URLRequest(url: url)
            request.httpMethod = "POST"
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")

            let artistData: [String: Any] = [
                "artistName": artistName,
                "artistImage": artistImage
            ]

            do {
                request.httpBody = try JSONSerialization.data(withJSONObject: artistData)
            } catch {
                print("Error encoding artist data:", error)
                completion(.failure(error))
                return
            }

            URLSession.shared.dataTask(with: request) { data, response, error in
                if let error = error {
                    print("Network error:", error)
                    DispatchQueue.main.async {
                        completion(.failure(error))
                    }
                    return
                }

                guard let data = data else {
                    print("No data received")
                    DispatchQueue.main.async {
                        completion(.failure(NSError(domain: "", code: 0, userInfo: [NSLocalizedDescriptionKey: "No data"])))
                    }
                    return
                }

                do {
                    let artist = try JSONDecoder().decode(Artist.self, from: data)
                    DispatchQueue.main.async {
                        completion(.success(artist))
                    }
                } catch {
                    print("Decoding error:", error)
                    DispatchQueue.main.async {
                        completion(.failure(error))
                    }
                }
            }.resume()
        }
    
    
    
    func getOrCreateArtist(artistName: String, completion: @escaping (String?) -> Void) {
        
        guard let url = URL(string: baseURL + "/getOrCreate") else {
            print("Invalid URL")
            completion(nil)
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")

        let body: [String: Any] = ["name": artistName]
        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: body, options: [])
        } catch {
            print("Error setting HTTP body: \(error)")
            completion(nil)
            return
        }

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Request error: \(error)")
                completion(nil)
                return
            }

            guard let data = data else {
                print("No data received")
                completion(nil)
                return
            }

            if let jsonString = String(data: data, encoding: .utf8) {
//                print("Response Data: \(jsonString)")
            }

            do {
                let responseObject = try JSONDecoder().decode([String: String].self, from: data)
                if let artistId = responseObject["artistId"] {
                    completion(artistId) 
                } else {
                    print("Error: No artistId in response")
                    completion(nil)
                }
            } catch {
                print("Error decoding response: \(error)")
                completion(nil)
            }
        }.resume()
        }
    
    
    
    
}
