//
//  UserDataService.swift
//  SetlistApp
//
//  Created by Student on 3/26/25.
//

import Foundation

class UserDataService {

    static let shared = UserDataService() 

//    private let baseURL = "http://localhost:3000/api/users"
    private let baseURL = "http://10.71.40.198:3000/api/users"
    
    var currentUser: User?
    
    func fetchUsers() {
            guard let url = URL(string: baseURL) else {
                print("Invalid URL")
                return
            }

            let task = URLSession.shared.dataTask(with: url) { data, response, error in
                if let error = error {
                    print("Error fetching data: \(error.localizedDescription)")
                    return
                }

                guard let data = data else {
                    print("No data received from server.")
                    return
                }

                if let jsonString = String(data: data, encoding: .utf8) {
//                    print("Raw JSON Users: \(jsonString)\n")
                }

                do {
                    let decoder = JSONDecoder()
                    let users = try decoder.decode([User].self, from: data)

                    for user in users {
//                        print("User ID: \(user.id)")
//                        print("Email: \(user.email)")
//                        print("Name: \(user.name)")
//                        print("Password: \(user.password)")
                        if let favoriteSetlists = user.favoriteSetlists {
//                                print("Favorite Setlists: \(favoriteSetlists)")
                            } else {
//                                print("Favorite Setlists: None")
                            }

//                        print("\n")
                    }
                } catch {
                    print("Error decoding user data: \(error.localizedDescription)")
                }
            }

            task.resume()
        }
    
    
    func registerUser(name: String, email: String, password: String, favoriteSetlists: [String] = [], completion: @escaping (Bool, String?) -> Void) {
            
            guard let url = URL(string: baseURL) else {
                completion(false, "Invalid URL")
                return
            }

            let userData: [String: Any] = [
                "name": name,
                "email": email,
                "password": password,
                "favoriteSetlists": favoriteSetlists
            ]

            guard let jsonData = try? JSONSerialization.data(withJSONObject: userData) else {
                completion(false, "Error encoding JSON")
                return
            }

            var request = URLRequest(url: url)
            request.httpMethod = "POST"
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.httpBody = jsonData

            let task = URLSession.shared.dataTask(with: request) { data, response, error in
                if let error = error {
                    completion(false, "Error: \(error.localizedDescription)")
                    return
                }

                guard let httpResponse = response as? HTTPURLResponse else {
                    completion(false, "Invalid server response")
                    return
                }

                if httpResponse.statusCode == 201 {
                    completion(true, nil)
                } else {
                    let errorMessage = "Failed to register. Status code: \(httpResponse.statusCode)"
                    completion(false, errorMessage)
                }
            }

            task.resume()
        }
    
    
    func loginUser(email: String, password: String, completion: @escaping (Bool, String?, String?, String?, String?) -> Void) {
        guard let url = URL(string: "\(baseURL)/login") else {
            completion(false, nil, nil, nil, "Invalid URL")
            return
        }

        let loginData: [String: Any] = [
            "email": email,
            "password": password
        ]

        guard let jsonData = try? JSONSerialization.data(withJSONObject: loginData) else {
            completion(false, nil, nil, nil, "Error encoding JSON")
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = jsonData

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                completion(false, nil, nil, nil, "Error: \(error.localizedDescription)")
                return
            }

            guard let httpResponse = response as? HTTPURLResponse else {
                completion(false, nil, nil, nil, "Invalid server response")
                return
            }

            if httpResponse.statusCode == 200, let data = data {
                do {
                    let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
                    let userId = json?["userId"] as? String
                    let userName = json?["name"] as? String
                    let userEmail = json?["email"] as? String
                    completion(true, userId, userName, userEmail, nil)
                } catch {
                    completion(false, nil, nil, nil, "Error decoding response")
                }
            } else {
                completion(false, nil, nil, nil, "Invalid email or password")
            }
        }

        task.resume()
    }
        
    
    
    
    
    func fetchUserById(userId: String, completion: @escaping (User?) -> Void) {
        guard let url = URL(string: "\(baseURL)/\(userId)") else {
            print("Invalid URL for user by ID")
            completion(nil)
            return
        }

        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                print("Error fetching user: \(error.localizedDescription)")
                completion(nil)
                return
            }

            guard let data = data else {
                print("No data received from server.")
                completion(nil)
                return
            }

            if let jsonString = String(data: data, encoding: .utf8) {
//                print("Raw JSON for user by ID: \(jsonString)")
            }

            do {
                let decoder = JSONDecoder()
                let user = try decoder.decode(User.self, from: data)
                completion(user)
            } catch {
                print("Error decoding user: \(error.localizedDescription)")
                completion(nil)
            }
        }

        task.resume()
    }
        
    
    
    
    func getFavoriteSetlists(userId: String, completion: @escaping (Result<[String], Error>) -> Void) {
            guard let url = URL(string: "\(baseURL)/\(userId)/favoriteSetlists") else {
                completion(.failure(NSError(domain: "", code: 400, userInfo: [NSLocalizedDescriptionKey: "Invalid URL"])))
                return
            }

            let task = URLSession.shared.dataTask(with: url) { data, response, error in
                if let error = error {
                    completion(.failure(error))
                    return
                }
                guard let data = data else {
                    completion(.failure(NSError(domain: "", code: 500, userInfo: [NSLocalizedDescriptionKey: "No data received"])))
                    return
                }

                do {
                    let decodedResponse = try JSONDecoder().decode(FavoriteSetlistResponse.self, from: data)
                    completion(.success(decodedResponse.favoriteSetlists ?? []))
                } catch {
                    completion(.failure(error))
                }
            }

            task.resume()
        }
    
    
    
    
}
