//
//  CreatedSetlistsCell.swift
//  SetlistApp
//
//  Created by Student on 3/14/25.
//

import UIKit

class CreatedSetlistsCell: UITableViewCell {
    
    @IBOutlet weak var setlistName: UILabel!
    
    func configure(with text: String) {
            setlistName.text = text
        }
}
