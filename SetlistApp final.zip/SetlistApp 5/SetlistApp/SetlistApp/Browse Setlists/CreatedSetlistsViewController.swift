//
//  CreatedSetlistsViewController.swift
//  SetlistApp
//
//  Created by Student on 3/14/25.
//

import UIKit

extension Notification.Name {
    static let didFetchSetlists = Notification.Name("didFetchSetlists")
}

class CreatedSetlistsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var tableView: UITableView!

    
    var userId: String?
        var setlists: [SetlistUploadDTO] = []
            
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
//            print("viewWillAppear - reloading data")
            
            SetlistDataService.shared.fetchSetlistsWithArtistNames()
        tableView.reloadData()
        
    }
    
    
        override func viewDidLoad() {
            super.viewDidLoad()
            
            tableView.delegate = self
            tableView.dataSource = self
            
            view.backgroundColor = .systemBackground
            setupHeader(title: "Browse")
            
//            print("CreatedSetlistViewController: viewDidLoad")

            
            SetlistDataService.shared.fetchSetlistsWithArtistNames()
            
            NotificationCenter.default.addObserver(self, selector: #selector(didFetchSetlists(_:)), name: .didFetchSetlists, object: nil)
        }
    
    override func viewDidDisappear(_ animated: Bool) {
//        print("view did disappear")
        super.viewDidDisappear(animated)
        
    }
    
    
    func reloadData() {
//            print("Reloading table data in CreatedSetlistsViewController")
            SetlistDataService.shared.fetchSetlistsWithArtistNames()
            tableView.reloadData() // Reload the table view to reflect the new setlist
        
        
        
        
        }
    
    
    
    
    func setupHeader(title: String) {
        let headerView = UIView()
            headerView.backgroundColor = UIColor.systemGray6
            headerView.translatesAutoresizingMaskIntoConstraints = false
            view.addSubview(headerView)
            
            NSLayoutConstraint.activate([
                headerView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
                headerView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
                headerView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
                headerView.heightAnchor.constraint(equalToConstant: 44)
            ])
            
            let titleLabel = UILabel()
            titleLabel.text = title
            titleLabel.font = UIFont.systemFont(ofSize: 17, weight: .regular)
            titleLabel.textColor = .darkGray
            titleLabel.translatesAutoresizingMaskIntoConstraints = false
            headerView.addSubview(titleLabel)
            
            NSLayoutConstraint.activate([
                titleLabel.centerXAnchor.constraint(equalTo: headerView.centerXAnchor),
                titleLabel.centerYAnchor.constraint(equalTo: headerView.centerYAnchor)
            ])
    }
        
    @objc func didFetchSetlists(_ notification: Notification) {
//        print("Calling didFetchSetlists method")
        guard let setlists = notification.object as? [SetlistUploadDTO] else {
               print("CreatedSetlistViewController: Failed to cast notification object to [SetlistUploadDTO]")
               return
           }
           
//           print("CreatedSetlistViewController: Fetched setlists - \(setlists.count) setlists received")

           DispatchQueue.main.async {
               if !setlists.isEmpty {
                   // Reverse the setlists array to make the most recent one appear at the top
                   self.setlists = setlists.reversed()
                   self.tableView.reloadData()
               } else {
//                   print("CreatedSetlistViewController: No setlists to display")
               }
           }
        }
    
    
    
    
        
        // MARK: - Table View Delegate and Data Source
        
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//            print("CreatedSetlistViewController: numberOfRowsInSection - \(setlists.count) rows")
            return setlists.count
        }
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

            let cell = tableView.dequeueReusableCell(withIdentifier: "CreatedSetlistsCell", for: indexPath)

               cell.contentView.subviews.forEach { $0.removeFromSuperview() }

               let setlist = setlists[indexPath.row]

               let setlistNameLabel = UILabel()
               setlistNameLabel.text = setlist.setlistName
               setlistNameLabel.font = UIFont.boldSystemFont(ofSize: 20)
               setlistNameLabel.textColor = .black
               setlistNameLabel.translatesAutoresizingMaskIntoConstraints = false
               setlistNameLabel.numberOfLines = 0

               let headlinerLabel = UILabel()
               let headlinerText = setlist.actualArtistNames.first ?? "Unknown Headliner"
               headlinerLabel.text = "Headliner: \(headlinerText)"
               headlinerLabel.font = UIFont.systemFont(ofSize: 16, weight: .medium)
               headlinerLabel.textColor = .black
               headlinerLabel.translatesAutoresizingMaskIntoConstraints = false
               headlinerLabel.numberOfLines = 0

               cell.contentView.addSubview(setlistNameLabel)
               cell.contentView.addSubview(headlinerLabel)

               NSLayoutConstraint.activate([
                   setlistNameLabel.topAnchor.constraint(equalTo: cell.contentView.topAnchor, constant: 10),
                   setlistNameLabel.leadingAnchor.constraint(equalTo: cell.contentView.leadingAnchor, constant: 15),
                   setlistNameLabel.trailingAnchor.constraint(equalTo: cell.contentView.trailingAnchor, constant: -15),

                   headlinerLabel.topAnchor.constraint(equalTo: setlistNameLabel.bottomAnchor, constant: 5),
                   headlinerLabel.leadingAnchor.constraint(equalTo: setlistNameLabel.leadingAnchor),
                   headlinerLabel.trailingAnchor.constraint(equalTo: setlistNameLabel.trailingAnchor),
                   headlinerLabel.bottomAnchor.constraint(equalTo: cell.contentView.bottomAnchor, constant: -10)
               ])

               return cell
            
        }
        
        func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            let selectedSetlist = setlists[indexPath.row]
//            print("CreatedSetlistViewController: didSelectRowAt - Setlist selected: \(selectedSetlist.setlistName), ID: \(selectedSetlist._id)")
            
            performSegue(withIdentifier: "setlistDetailSegue", sender: selectedSetlist)
        }

    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 75 
    }
    
        override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            if segue.identifier == "setlistDetailSegue" {
                if let setlistDetailVC = segue.destination as? SetlistDetailViewController {
                    if let selectedSetlist = sender as? SetlistUploadDTO {
//                        print("CreatedSetlistViewController: prepare(for:sender:) - Passing setlist ID: \(selectedSetlist._id) to SetlistDetailViewController")
                        setlistDetailVC.setlistId = selectedSetlist._id
                        setlistDetailVC.userId = self.userId
                    } else {
                        print("CreatedSetlistViewController: prepare(for:sender:) - sender is not SetlistUploadDTO")
                    }
                } else {
                    print("CreatedSetlistViewController: prepare(for:sender:) - Failed to get SetlistDetailViewController from segue destination")
                }
            }
        }
    }
