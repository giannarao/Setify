//
//  MainTabBarController.swift
//  SetlistApp
//
//  Created by Student on 4/1/25.
//

//don't need this file

//import UIKit
//
//class MainTabBarController: UITabBarController {
//
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        
//        self.navigationController?.setNavigationBarHidden(true, animated: false)
//
//        // Disable swipe-to-go-back gesture
//        self.navigationController?.interactivePopGestureRecognizer?.isEnabled = false
//    }
//}
