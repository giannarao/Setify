//
//  SetlistModelUploadDTO.swift
//  SetlistApp
//
//  Created by Student on 4/9/25.
//

import Foundation

struct SetlistUploadDTO: Codable {
    var _id: String
    var date_location: [DateLocation]
    var setlistName: String
    var setlistImage: String
    var createdBy: String
    var tourName: String
    var headlinerName: String
    var openerNames: [Opener]
    var headlinerSongIDs: [String]
    var actualArtistNames: [String]
    var actualOpenerNames: [String]
    var actualHeadlinerSongNames: [String]
    var actualOpenerSongNames: [String]


    struct Opener: Codable {
        var name: String
        var songs: [String]

        enum CodingKeys: String, CodingKey {
            case name
            case songs
        }

        init(name: String, songs: [String]) {
            self.name = name
            self.songs = songs
        }
    }
    
    
    
    struct DateLocation: Codable {
        let date: String // ISO8601 date string
        let city: String
        
        var formattedDate: String {
            
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSZ"
            dateFormatter.timeZone = TimeZone(abbreviation: "UTC")
            
            if let date = dateFormatter.date(from: self.date) {
               
                let outputFormatter = DateFormatter()
                outputFormatter.dateFormat = "MMMM d, yyyy"
                
                outputFormatter.timeZone = TimeZone(abbreviation: "EST")
               
                let adjustedDate = date.addingTimeInterval(TimeInterval(TimeZone.current.secondsFromGMT(for: date)))
                
                return outputFormatter.string(from: adjustedDate)
            }
            
            print("Failed to parse date: \(self.date)")
            return self.date
        }
    }
}


struct FavoriteSetlistResponse: Decodable {
    let favoriteSetlists: [String]?
    
    enum CodingKeys: String, CodingKey {
            case favoriteSetlists
        }
        
        init(from decoder: Decoder) throws {
            let container = try decoder.container(keyedBy: CodingKeys.self)
            
            
            favoriteSetlists = try? container.decode([String].self, forKey: .favoriteSetlists)
        }
    
}

