//
//  UserModel.swift
//  SetlistApp
//
//  Created by Student on 3/26/25.
//

import Foundation

struct User: Codable {
    let id: String
    let email: String
    let name: String
    let password: String?
    let favoriteSetlists: [String]?

    enum CodingKeys: String, CodingKey {
        case id = "_id"
        case email
        case name
        case password
        case favoriteSetlists
    }
}
