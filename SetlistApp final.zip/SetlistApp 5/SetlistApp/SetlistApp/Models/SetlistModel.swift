//
//  SetlistModel.swift
//  SetlistApp
//
//  Created by Student on 3/26/25.
//

import Foundation

struct Setlist: Codable {
    let id: String
    let setlistName: String
    let setlistImage: String?
    let createdBy: String
    let tourName: String
    let headlinerName: String
    let dateLocation: [DateLocation]
    let openerNames: [String]
    let headlinerSongIDs: [String]
    
    var actualArtistNames: [String]
    var actualOpenerNames: [String]?
    
    var actualHeadlinerSongNames: [String]?
    var actualOpenerSongNames: [String]?

    enum CodingKeys: String, CodingKey {
        case id = "_id"
        case setlistName
        case setlistImage
        case createdBy
        case tourName
        case headlinerName
        case dateLocation = "date_location"
        case openerNames
        case headlinerSongIDs
        case actualArtistNames
        case actualOpenerNames
        case actualHeadlinerSongNames
        case actualOpenerSongNames
    }
    
}





struct DateLocation: Codable {
    let date: String // ISO8601 date string
    let city: String
    
    var formattedDate: String {
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSZ"
        dateFormatter.timeZone = TimeZone(abbreviation: "UTC")
        
        if let date = dateFormatter.date(from: self.date) {
           
            let outputFormatter = DateFormatter()
            outputFormatter.dateFormat = "MMMM d, yyyy"
            
            outputFormatter.timeZone = TimeZone(abbreviation: "EST")
           
            let adjustedDate = date.addingTimeInterval(TimeInterval(TimeZone.current.secondsFromGMT(for: date)))
            
            return outputFormatter.string(from: adjustedDate)
        }
        
        print("Failed to parse date: \(self.date)")
        return self.date
    }
}



