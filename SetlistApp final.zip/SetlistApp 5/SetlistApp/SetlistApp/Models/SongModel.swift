//
//  SongModel.swift
//  SetlistApp
//
//  Created by Student on 3/26/25.
//

import Foundation

struct Song: Codable {
    var id: String
    let songTitle: String
    var artistIDs: [String]
    var audio: String
    var lyrics: String
    
    
    
    enum CodingKeys: String, CodingKey {
        case id = "_id"
        case songTitle
        case artistIDs
        case audio
        case lyrics
    }
}
