//
//  OpenerModel.swift
//  SetlistApp
//
//  Created by Student on 4/8/25.
//

import Foundation

struct Opener: Codable {
    let name: String
    let songs: [String]
}
