//
//  ArtistModel.swift
//  SetlistApp
//
//  Created by Student on 3/26/25.
//

import Foundation

struct Artist: Codable {
    let id: String
    let artistName: String
    let artistImage: String?
    
    enum CodingKeys: String, CodingKey {
        case id = "_id"
        case artistName
        case artistImage
    }
}
