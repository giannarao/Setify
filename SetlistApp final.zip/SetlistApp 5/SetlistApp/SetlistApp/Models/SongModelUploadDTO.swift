//
//  SongModelUploadDTO.swift
//  SetlistApp
//
//  Created by Student on 4/9/25.
//

import Foundation

struct SongModelUploadDTO: Codable {
    var id: String
    let songTitle: String
    var artistIDs: [Artist]  
    var audio: String
    var lyrics: String
    
    enum CodingKeys: String, CodingKey {
        case id = "_id"
        case songTitle
        case artistIDs
        case audio
        case lyrics
    }
}
