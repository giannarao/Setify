//
//  AddSetlistViewController.swift
//  SetlistApp
//
//  Created by Student on 3/21/25.
//

import UIKit

class AddSetlistViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate{
    
//    let baseURL = "http://localhost:3000/api/spotify"
    let baseURL = "http://10.71.40.198:3000/api/spotify"
    
    @IBOutlet weak var setlistNameTextField: UITextField!
    
    @IBOutlet weak var tourNameTextField: UITextField!
    
    
    @IBOutlet weak var tableViewLabel: UILabel!
    @IBOutlet weak var dateTextField: UITextField!
    
    @IBOutlet weak var cityName: UITextField!
    
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var infoStackView: UIStackView!
    
    @IBOutlet weak var addSetlistLabel: UILabel!
    
    
    
    
    private let datePicker = UIDatePicker()
        private let formatter: DateFormatter = {
            let df = DateFormatter()
            df.dateStyle = .medium
            df.timeStyle = .none
            return df
        }()
    
    
    
    
       var matchingArtists: [String] = []
       var headliner: String = ""
       var openersArray: [String] = []
       
       var artistInputField: UITextField?
       var addArtistButton: UIButton!
       var artistSummaryLabel: UILabel!
       
       var userId: String?

       override func viewDidLoad() {
           super.viewDidLoad()


           
           tableView.delegate = self
           tableView.dataSource = self
           tableView.register(UITableViewCell.self, forCellReuseIdentifier: "Cell")
           tableView.isHidden = true
           tableViewLabel.isHidden = true
           
           
           tableView.register(UITableViewCell.self, forCellReuseIdentifier: "Cell")

               if let savedUserId = UserDefaults.standard.string(forKey: "userId") {
                   userId = savedUserId
                   //print("User ID fetched from UserDefaults: \(userId ?? "nil")")
               } else {
                   print("Error: No user ID found in UserDefaults")
               }
           
           
           setupAddArtistButton()
           setupArtistSummaryLabel()
           
           
           
           
           
           setupDatePicker()
           
           
           
           
           
           
           infoStackView.layer.cornerRadius = 10
           infoStackView.layer.borderWidth = 1
           infoStackView.layer.borderColor = UIColor.gray.cgColor
           infoStackView.layer.masksToBounds = true
           infoStackView.isLayoutMarginsRelativeArrangement = true
           infoStackView.layoutMargins = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
           
           infoStackView.topAnchor.constraint(equalTo: addSetlistLabel.bottomAnchor, constant: 10).isActive = true
           
           
           
           
           

           
           view.backgroundColor = .systemBackground
           setupHeader(title: "Add Setlist")
           

           
           setupKeyboardToolbar(for: setlistNameTextField)
               setupKeyboardToolbar(for: tourNameTextField)
               //setupKeyboardToolbar(for: dateTextField)
               setupKeyboardToolbar(for: cityName)
           
           NotificationCenter.default.addObserver(self,
                                                          selector: #selector(keyboardWillShow(_:)),
                                                          name: UIResponder.keyboardWillShowNotification,
                                                          object: nil)
                   
                   NotificationCenter.default.addObserver(self,
                                                          selector: #selector(keyboardWillHide(_:)),
                                                          name: UIResponder.keyboardWillHideNotification,
                                                          object: nil)
                   
                   artistInputField?.delegate = self
           
           
       }
    
   
    
    @objc func keyboardWillShow(_ notification: Notification) {
            if let artistInputField = artistInputField, artistInputField.isFirstResponder {
                setupKeyboardToolbar(for: artistInputField)
            }
        }
        
        @objc func keyboardWillHide(_ notification: Notification) {
            
        }
        
        private func setupKeyboardToolbar(for textField: UITextField) {
            let toolbar = UIToolbar()
            toolbar.sizeToFit()

            let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(dismissKeyboard))
            toolbar.setItems([doneButton], animated: false)

            textField.inputAccessoryView = toolbar
        }
        
        @objc func dismissKeyboard() {
            view.endEditing(true)
        }
        
        deinit {
            NotificationCenter.default.removeObserver(self)
        }
    
    
   
    
    private func setupDatePicker() {
            datePicker.datePickerMode = .date
            if #available(iOS 13.4, *) {
                datePicker.preferredDatePickerStyle = .wheels
            }

            dateTextField.inputView = datePicker

            let toolbar = UIToolbar()
            toolbar.sizeToFit()
            let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(doneTapped))
            toolbar.setItems([doneButton], animated: true)
            dateTextField.inputAccessoryView = toolbar
        }

        @objc private func doneTapped() {
            dateTextField.text = formatter.string(from: datePicker.date)
            dateTextField.resignFirstResponder()
        }
    
    
    
    
    
    
    func setupHeader(title: String) {
        let headerView = UIView()
            headerView.backgroundColor = UIColor.systemGray6
            headerView.translatesAutoresizingMaskIntoConstraints = false
            view.addSubview(headerView)
            
            NSLayoutConstraint.activate([
                headerView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
                headerView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
                headerView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
                headerView.heightAnchor.constraint(equalToConstant: 44)
            ])
            
            let titleLabel = UILabel()
            titleLabel.text = title
            titleLabel.font = UIFont.systemFont(ofSize: 17, weight: .regular)
            titleLabel.textColor = .darkGray
            titleLabel.translatesAutoresizingMaskIntoConstraints = false
            headerView.addSubview(titleLabel)
            
            NSLayoutConstraint.activate([
                titleLabel.centerXAnchor.constraint(equalTo: headerView.centerXAnchor),
                titleLabel.centerYAnchor.constraint(equalTo: headerView.centerYAnchor)
            ])
    }
    
    
    
    
       
       func setupAddArtistButton() {
           addArtistButton = UIButton(type: .system)
           addArtistButton.setTitle("Add Artists", for: .normal)
           addArtistButton.translatesAutoresizingMaskIntoConstraints = false
           addArtistButton.addTarget(self, action: #selector(addArtistButtonTapped), for: .touchUpInside)
           view.addSubview(addArtistButton)

           NSLayoutConstraint.activate([
               addArtistButton.topAnchor.constraint(equalTo: cityName.bottomAnchor, constant: 16),
               addArtistButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
               addArtistButton.heightAnchor.constraint(equalToConstant: 40)
           ])
       }
       
       func setupArtistSummaryLabel() {
           artistSummaryLabel = UILabel()
           artistSummaryLabel.numberOfLines = 0
           artistSummaryLabel.font = .systemFont(ofSize: 16)
           artistSummaryLabel.translatesAutoresizingMaskIntoConstraints = false
           view.addSubview(artistSummaryLabel)

           NSLayoutConstraint.activate([
                artistSummaryLabel.topAnchor.constraint(equalTo: cityName.bottomAnchor, constant: 25),
               artistSummaryLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
               artistSummaryLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20)
           ])
       }
       
       func setupArtistInputField() {

           let inputField = UITextField()
           inputField.placeholder = headliner.isEmpty ? "Enter headliner name" : "Enter opener name"
           inputField.borderStyle = .roundedRect
           inputField.translatesAutoresizingMaskIntoConstraints = false
           inputField.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
           view.addSubview(inputField)
           artistInputField = inputField

           NSLayoutConstraint.activate([
               inputField.topAnchor.constraint(equalTo: addArtistButton.bottomAnchor, constant: 30),
               inputField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
               inputField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
               inputField.heightAnchor.constraint(equalToConstant: 40)
           ])
       }

       @objc func addArtistButtonTapped() {
           if artistInputField == nil {
               setupArtistInputField()
           } else if let inputText = artistInputField?.text, !inputText.isEmpty {
               if headliner.isEmpty {
                   headliner = inputText
                   artistInputField?.text = ""
                   artistInputField?.placeholder = "Enter opener name"
               } else {
                   openersArray.append(inputText)
                   artistInputField?.text = ""
               }
               updateArtistLabel()
           }
           
           addArtistButton.isHidden = true
       }

       func updateArtistLabel() {
           var labelText = ""
           if !headliner.isEmpty {
               labelText += "Headliner: \(headliner)"
           }
           if !openersArray.isEmpty {
               labelText += "\nOpeners: \(openersArray.joined(separator: ", "))"
           }
           artistSummaryLabel.text = labelText
       }

       @objc func textFieldDidChange(_ textField: UITextField) {
           guard let query = textField.text, !query.isEmpty else {
               matchingArtists = []
               tableView.reloadData()
               tableView.isHidden = true
               tableViewLabel.isHidden = true
               return
           }

         
           
           let queryEncoded = query.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
           let urlString = "\(baseURL)/search-artist?artist=\(queryEncoded)"

           guard let url = URL(string: urlString) else { return }

           URLSession.shared.dataTask(with: url) { data, response, error in
               if let data = data {
                   do {
                       let artists = try JSONDecoder().decode([String].self, from: data)
                       DispatchQueue.main.async {
                           self.matchingArtists = artists
                           self.tableView.reloadData()
                           self.tableView.isHidden = artists.isEmpty
                           self.tableViewLabel.isHidden = artists.isEmpty
                       }
                   } catch {
                       print("Decoding error: \(error)")
                   }
               } else if let error = error {
                   print("Request error: \(error)")
               }
           }.resume()
       }

       func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
           return matchingArtists.count
       }

       func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
           let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
           cell.textLabel?.text = matchingArtists[indexPath.row]
           return cell
       }

       func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
           let selected = matchingArtists[indexPath.row]
           
           if headliner.isEmpty {
               headliner = selected
               artistInputField?.placeholder = "Enter opener name"
           } else {
               openersArray.append(selected)
           }

           artistInputField?.text = ""
           matchingArtists = []
           tableView.reloadData()
           tableView.isHidden = true
           tableViewLabel.isHidden = true

           updateArtistLabel()
       }
    
    
  
    
    @IBAction func submitButtonTapped(_ sender: Any) {
        
        //print("Submit button tapped")

            guard let userId = userId else {
                print("Error: No user is logged in")
                return
                
            }

        
        guard let setlistName = setlistNameTextField.text, !setlistName.isEmpty else {
                showErrorPopup(message: "Setlist Name is required")
                return
            }

            guard let tourName = tourNameTextField.text, !tourName.isEmpty else {
                showErrorPopup(message: "Tour Name is required")
                return
            }

            guard let date = dateTextField.text, !date.isEmpty else {
                showErrorPopup(message: "Date is required")
                return
            }

            guard let city = cityName.text, !city.isEmpty else {
                showErrorPopup(message: "City is required")
                return
            }

            guard !headliner.isEmpty else {
                showErrorPopup(message: "Headliner is required")
                return
            }

        
        
//            let setlistName = setlistNameTextField.text ?? ""
//            let tourName = tourNameTextField.text ?? ""
//            let date = dateTextField.text ?? ""
//            let city = cityName.text ?? ""
            let allArtists = [headliner] + openersArray
            
//            print("Setlist Name: \(setlistName)")
//            print("Tour Name: \(tourName)")
//            print("Date: \(date)")
//            print("City: \(city)")
//            print("Headliner: \(headliner)")
//            print("Openers: \(openersArray)")

            ArtistDataService.shared.getOrCreateArtist(artistName: headliner) { artistId in
                //print("Headliner Artist ID: \(artistId)")

                var openerIds: [String] = []
                let group = DispatchGroup()

                for opener in self.openersArray {
                    group.enter()
                    ArtistDataService.shared.getOrCreateArtist(artistName: opener) { artistId in
                        //print("\(opener) Artist ID: \(artistId)")
                        openerIds.append(artistId ?? "unknown artistId")
                        group.leave()
                    }
                }

                group.notify(queue: .main) { [self] in
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    if let addSongsVC = storyboard.instantiateViewController(withIdentifier: "AddSongsViewController") as? AddSongsViewController {
                        
                        addSongsVC.setlistName = setlistName
                        addSongsVC.headlinerName = self.headliner
                        addSongsVC.openerNames = self.openersArray
                        addSongsVC.tourName = tourName
                        addSongsVC.createdBy = userId
                        //print("AddSetlist createdBy: \(userId)")
                        addSongsVC.date = date
                        addSongsVC.city = city
                        addSongsVC.headlinerArtistId = artistId ?? "unknown headlinerArtistId"
                        addSongsVC.openerArtistIds = openerIds
                        
//                        print("Passing to Add Songs")
//                        print("Setlist name: \(setlistName)")
//                        print("Headliner name (headlinerName: \(self.headliner)")
//                        print("Opener names (openerNames): \(openersArray)")
//                        print("Tour name: \(tourName)")
//                        print("Created by: \(userId)")
//                        print("Date: \(date)")
//                        print("City: \(city)")
//                        print("headlinerArtistId: \(artistId)")
//                        print("openerArtistIds: \(openerIds)")
                        
                        
                        
                        addSongsVC.modalPresentationStyle = .fullScreen
                        self.present(addSongsVC, animated: true, completion: nil)
                    } else {
                        print("Error: Could not instantiate AddSongsViewController")
                    }
                }
            }
        }

        
    private func showErrorPopup(message: String) {
        let alertController = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alertController.addAction(okAction)
        present(alertController, animated: true, completion: nil)
    }
            
    
    
    
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
            if textField == artistInputField {
                setupKeyboardToolbar(for: textField)
            }
        }
    
    
        func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
            if textField == artistInputField {
                setupKeyboardToolbar(for: textField) 
            }
            return true
        }
    
    
}




