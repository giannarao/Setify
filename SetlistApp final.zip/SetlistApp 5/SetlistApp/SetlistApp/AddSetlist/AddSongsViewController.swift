//
//  AddSongsViewController.swift
//  SetlistApp
//
//  Created by Student on 4/16/25.
//

import UIKit

protocol AddSongsViewControllerDelegate: AnyObject {
    func didSubmitNewSetlist()
}



class AddSongsViewController: UIViewController,  UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate {
    
    
//    let baseURL = "http://localhost:3000/api/spotify"
    let baseURL = "http://10.71.40.198:3000/api/spotify"
    
    weak var delegate: AddSongsViewControllerDelegate?
    
    
    var tableView: UITableView!
    var searchTextField: UITextField!
    
    var setlistName: String = ""
    var headlinerName: String = ""
    var openerNames: [String] = []
    var tourName: String = ""
    var createdBy: String = ""
    var date: String = ""
    var city: String = ""
    
    var headlinerArtistId: String?
    var openerArtistIds: [String]?
    
    var headlinerSongIDs: [String] = []
    var openerSongs: [String: [String]] = [:]
    
    var songResults: [String] = []
    var selectedOpener: String?
    
    
    
    
    var isSearchFieldVisible = false {
        didSet {
            searchTextField.isHidden = !isSearchFieldVisible
        }
    }
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        print("AddSongsViewController Loaded")
//        print("Headliner: \(headlinerName), Openers: \(openerNames)")
        
        setupTableView()
        setupSearchControls()
        setupCloseButton()
        
        setupSubmitButton()
        
        isSearchFieldVisible = false
            searchTextField.isHidden = true
        
        
    }
    
    
    func setupTableView() {
        
        tableView = UITableView(frame: self.view.bounds, style: .grouped)
            tableView.delegate = self
            tableView.dataSource = self
            tableView.register(UITableViewCell.self, forCellReuseIdentifier: "Cell")
            tableView.translatesAutoresizingMaskIntoConstraints = false
            view.addSubview(tableView)
            
            NSLayoutConstraint.activate([
                tableView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 50),
                tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
                tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
                tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -60)
            ])
    }
    
    func setupSearchControls() {
        
        searchTextField = UITextField()
        searchTextField.placeholder = "Search for a song"
        searchTextField.borderStyle = .roundedRect
        searchTextField.addTarget(self, action: #selector(searchTextFieldChanged), for: .editingChanged)
        searchTextField.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(searchTextField)
        
        
        let toolbar = UIToolbar()
            toolbar.sizeToFit()
            
            let doneButton = UIBarButtonItem(title: "Done", style: .done, target: self, action: #selector(doneButtonTapped))
            toolbar.setItems([doneButton], animated: true)
            
            searchTextField.inputAccessoryView = toolbar
        
        
        NSLayoutConstraint.activate([
            searchTextField.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 10), // Move search bar to top
            searchTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            searchTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            searchTextField.heightAnchor.constraint(equalToConstant: 40)
        ])
        
    }
    
    @objc func doneButtonTapped() {
        searchTextField.resignFirstResponder()
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1 + openerNames.count + 1 // 1 for Search Results, 1 for Headliner + Openers
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 { return songResults.count }
        
        if section == 1 { return headlinerSongIDs.count }
        
        let opener = openerNames[section - 2]
        return openerSongs[opener]?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if section == 0 { return "Search Results" }
        
        if section == 1 { return "\(headlinerName) (Headliner)" }
        
        let opener = openerNames[section - 2]
        return "\(opener) (Opener)"
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView()
        headerView.backgroundColor = .systemGray6
        
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = UIFont.boldSystemFont(ofSize: 18)
        
        if section == 0 {
            label.text = ""
        } else if section == 1 {
            label.text = "\(headlinerName) (Headliner)"
        } else {
            let opener = openerNames[section - 2]
            label.text = "\(opener) (Opener) "
        }
        
        headerView.addSubview(label)
        
        
        if section != 0 {
            let addButton = UIButton(type: .system)
            addButton.setTitle("Add Song", for: .normal)
            addButton.setTitleColor(.systemBlue, for: .normal)
            addButton.titleLabel?.font = UIFont.systemFont(ofSize: 14)
            addButton.translatesAutoresizingMaskIntoConstraints = false
            addButton.tag = section
            addButton.addTarget(self, action: #selector(addSongsButtonTapped(_:)), for: .touchUpInside)
            
            headerView.addSubview(addButton)
            
            NSLayoutConstraint.activate([
                addButton.trailingAnchor.constraint(equalTo: headerView.trailingAnchor, constant: -16),
                addButton.centerYAnchor.constraint(equalTo: headerView.centerYAnchor),
            ])
        }
        
        NSLayoutConstraint.activate([
            label.leadingAnchor.constraint(equalTo: headerView.leadingAnchor, constant: 16),
            label.centerYAnchor.constraint(equalTo: headerView.centerYAnchor),
            label.topAnchor.constraint(equalTo: headerView.topAnchor, constant: 8),
        ])
        
        return headerView
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        cell.accessoryView = nil
        cell.selectionStyle = .none
        
        if indexPath.section == 0 {
            let songTitle = songResults[indexPath.row]
            cell.textLabel?.text = songTitle
            cell.selectionStyle = .default
        } else if indexPath.section == 1 {
            let songID = headlinerSongIDs[indexPath.row]
            SongDataService.shared.fetchSongByID(songId: songID) { song in
                DispatchQueue.main.async {
                    if let song = song {
                        cell.textLabel?.text = song.songTitle
                    } else {
                        cell.textLabel?.text = "Unknown Song"
                    }
                }
            }
        } else {
            let opener = openerNames[indexPath.section - 2]
            if let songIDs = openerSongs[opener], indexPath.row < songIDs.count {
                let songID = songIDs[indexPath.row]
                SongDataService.shared.fetchSongByID(songId: songID) { song in
                    DispatchQueue.main.async {
                        if let song = song {
                            cell.textLabel?.text = song.songTitle
                        } else {
                            cell.textLabel?.text = "Unknown Song"
                        }
                    }
                }
            }
        }
        
        return cell
        
        
    }
    
    @objc func addSongsButtonTapped(_ sender: UIButton) {
        if sender.tag == 1 {
            selectedOpener = nil
//            print("Adding to Headliner")
            isSearchFieldVisible = true
//            }
        } else {
            selectedOpener = openerNames[sender.tag - 2]
//            print("Adding to Opener: \(selectedOpener ?? "")")
            isSearchFieldVisible = true
        }
    }
    
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard indexPath.section == 0 else { return }
        
        let selectedSong = songResults[indexPath.row]
//        print("Selected song: \(selectedSong)")
        
        let artistName: String
        
        if selectedOpener == nil {
            artistName = headlinerName
        } else {
            artistName = selectedOpener ?? ""
        }
        
//        print("Artist Name: \(artistName)")
        
        SongDataService.shared.getOrAddSong(songTitle: selectedSong, artistName: artistName) { [weak self] song in
            guard let self = self, let song = song else { return }
            
//            print("Song ID for '\(selectedSong)': \(song.id)") 
            
            if let opener = self.selectedOpener {
                self.openerSongs[opener, default: []].append(song.id)
//                print("Added song '\(selectedSong)' to opener \(opener)")
//                print("Current opener songs: \(self.openerSongs)")
            } else {
                self.headlinerSongIDs.append(song.id)
//                print("Added song '\(selectedSong)' to headliner")
//                print("Current headliner songs: \(self.headlinerSongIDs)")
            }
            
            DispatchQueue.main.async {
                self.searchTextField.text = ""
                self.songResults = []
                self.isSearchFieldVisible = false
                tableView.reloadData()
            }
        }
    }
    
    @objc func searchTextFieldChanged() {
        guard let text = searchTextField.text, !text.isEmpty else {
            songResults = []
            tableView.reloadData()
            return
        }
        searchForSong(text)
    }
    
    func searchForSong(_ title: String) {
        
        let query = title.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        let urlString = "\(baseURL)/search-song?song=\(query)"

        guard let url = URL(string: urlString) else { return }
        
        
        URLSession.shared.dataTask(with: url) { data, _, error in
            if let error = error {
                print("Search error: \(error.localizedDescription)")
                return
            }
            guard let data = data else { return }
            do {
                let results = try JSONDecoder().decode([String].self, from: data)
                DispatchQueue.main.async {
                    self.songResults = results
                    self.tableView.reloadData()
                }
            } catch {
                print("Decode error: \(error)")
            }
        }.resume()
    }
    
    func setupCloseButton() {
        let closeButton = UIButton(type: .system)
        closeButton.setTitle("Back", for: .normal)
        closeButton.setTitleColor(.white, for: .normal)
        closeButton.backgroundColor = .red
        closeButton.layer.cornerRadius = 5
        closeButton.titleLabel?.font = UIFont.systemFont(ofSize: 14, weight: .medium)
        closeButton.addTarget(self, action: #selector(dismissViewController), for: .touchUpInside)

        closeButton.frame = CGRect(x: self.view.bounds.width - 100, y: 30, width: 80, height: 32)

        self.view.addSubview(closeButton)
    }
    
    @objc func dismissViewController() {
        self.dismiss(animated: true, completion: nil)
    }
    
    
    
    
    func validateSongs() -> Bool {
        if headlinerSongIDs.isEmpty {
            showAlert(message: "The headliner must have at least one song.")
            return false
        }
        
        for opener in openerNames {
            if openerSongs[opener]?.isEmpty ?? true {
                showAlert(message: "Each opener must have at least one song.")
                return false
            }
        }
        
        return true
    }

    func showAlert(message: String) {
        let alertController = UIAlertController(title: "Validation Error", message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default)
        alertController.addAction(okAction)
        present(alertController, animated: true)
    }
    
    
    func setupSubmitButton() {
        let submitButton = UIButton(type: .system)
        submitButton.setTitle("Submit", for: .normal)
        submitButton.setTitleColor(.white, for: .normal)
        submitButton.backgroundColor = .blue
        submitButton.layer.cornerRadius = 5
        submitButton.translatesAutoresizingMaskIntoConstraints = false
        submitButton.addTarget(self, action: #selector(submitButtonTapped), for: .touchUpInside)
        
        view.addSubview(submitButton)
        
        NSLayoutConstraint.activate([
            submitButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -16),
            submitButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            submitButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            submitButton.heightAnchor.constraint(equalToConstant: 50)
        ])
    }
    
    @objc func submitButtonTapped() {
        
//        print("Submit button tapped")
        
 
            if validateSongs() {
//                print("Setlist is valid. Proceeding with submission...")
            } else {
                print("Setlist is not valid. Please check the songs.")
                return
            }
        
        // Printing data for debugging
//        print("Setlist Name: \(setlistName)")
//        print("Setlist Image: (hardcode this)")
//        print("Created by: \(createdBy)")
//        print("Tour Name: \(tourName)")
//        print("Headliner Name headlinerName: \(headlinerName)")
//        print("Headliner Name headlinerArtistId: \(headlinerArtistId ?? "Not available")")
//        print("Date: \(date)")
//        print("City: \(city)")
//        print("Opener Names openerArtistIds: \(openerArtistIds ?? ["No artists"])")
//        print("Opener Names openerSongs: \(openerSongs)")
//        print("Headliner Song Ids: \(headlinerSongIDs)")
        
        var submitOpenerSongs: [String: [String]] = [:]
        let dispatchGroup = DispatchGroup()
        
        for (artistName, songIDs) in openerSongs {
            dispatchGroup.enter()

            ArtistDataService.shared.fetchArtistByName(artistName: artistName) { artist in
                if let artist = artist {
                    submitOpenerSongs[artist.id] = songIDs
                } else {
                    print("Error: Could not fetch artist ID for \(artistName)")
                }
                dispatchGroup.leave()
            }
        }
        
        dispatchGroup.notify(queue: .main) {
//            print("submitOpenerSongs with Artist IDs:")
//            print(submitOpenerSongs)
            
            let submittedSetlist = Setlist(
                id: "1234",
                setlistName: self.setlistName,
                setlistImage: "imageName.jpg",
                createdBy: self.createdBy,
                tourName: self.tourName,
                headlinerName: self.headlinerArtistId ?? "Unknown headliner",
                dateLocation: [
                    DateLocation(date: self.date, city: self.city)
                ],
                openerNames: Array(submitOpenerSongs.keys),
                headlinerSongIDs: self.headlinerSongIDs,
                actualArtistNames: [],
                actualOpenerNames: [],
                actualHeadlinerSongNames: [],
                actualOpenerSongNames: []
            )

            SetlistDataService.shared.addSetlist(setlist: submittedSetlist, openerSongs: submitOpenerSongs) { success, error in
                if success {
//                    print("Setlist added successfully.")
                } else if let error = error {
                    print("Failed to add setlist: \(error.localizedDescription)")
                } else {
                    print("Failed to add setlist: Unknown error.")
                }
            }
            
            var presentingVC = self.presentingViewController
            
            while presentingVC != nil && !(presentingVC is UITabBarController) {
                presentingVC = presentingVC?.presentingViewController
            }
            
            if let tabBarController = presentingVC as? UITabBarController {
//                print("Found UITabBarController")
                
                if let createdSetlistsVC = tabBarController.viewControllers?.first(where: { $0 is CreatedSetlistsViewController }) as? CreatedSetlistsViewController {
                    createdSetlistsVC.reloadData()
                }
                
                tabBarController.dismiss(animated: true) {
                    tabBarController.selectedIndex = 0
//                    print("Returned to CreatedSetlists tab")
                }
            } else {
                print("TabBarController not found in presenting hierarchy")
            }
        }
    }
                
    
                
    
    
    
   }












    
