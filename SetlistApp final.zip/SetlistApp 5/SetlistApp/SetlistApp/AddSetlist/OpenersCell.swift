//
//  OpenersCell.swift
//  SetlistApp
//
//  Created by Student on 3/21/25.
//

import UIKit

class OpenersCell: UITableViewCell {
    
    @IBOutlet weak var songName: UILabel!
    
}
