//
//  HeadlinerCell.swift
//  SetlistApp
//
//  Created by Student on 3/21/25.
//

import UIKit

class HeadlinerCell: UITableViewCell {
    
    @IBOutlet weak var songName: UILabel!
    
    override func awakeFromNib() {
            super.awakeFromNib()
        
        }

        override func setSelected(_ selected: Bool, animated: Bool) {
            super.setSelected(selected, animated: animated)
        }

        func configureCell(song: String) {
            songName.text = song
        }
    
}
