//
//  LoginViewController.swift
//  SetlistApp
//
//  Created by Student on 3/14/25.
//

import UIKit

class LoginViewController: UIViewController {
    
    @IBOutlet weak var password: UITextField!
    
    @IBOutlet weak var email: UITextField!
    
    
    override func viewDidLoad() {
            super.viewDidLoad()
            navigationController?.interactivePopGestureRecognizer?.isEnabled = false
        
        password.isSecureTextEntry = true
        }
        
        @IBAction func loginButton(_ sender: Any) {
            guard let email = email.text, !email.isEmpty else {
                showAlert(message: "Please enter your email.")
                return
            }

            guard let password = password.text, !password.isEmpty else {
                showAlert(message: "Please enter your password.")
                return
            }
            
            UserDataService.shared.loginUser(email: email, password: password) { (success, userId, userName, userEmail, errorMessage) in
                if success {
                    //print("Login successful!")
                    DispatchQueue.main.async {
                        
                        if let userId = userId {
                            UserDefaults.standard.set(userId, forKey: "userId")
                            //print("UserId saved to UserDefaults: \(userId)")
                        }

                        //print("User Details: userId = \(userId ?? "nil"), userName = \(userName ?? "nil"), userEmail = \(userEmail ?? "nil")")

                        if let tabBarController = self.storyboard?.instantiateViewController(withIdentifier: "MainTabBarController") as? UITabBarController {
                            
                            if let accountInfoVC = tabBarController.viewControllers?.first(where: { $0 is AccountInfoViewController }) as? AccountInfoViewController {
                                //print("Found AccountInfoViewController")
                                accountInfoVC.userName = userName
                                accountInfoVC.userEmail = userEmail
                                //print("Passed data: userName = \(userName ?? "nil"), userEmail = \(userEmail ?? "nil")")
                            } else {
                                //print("AccountInfoViewController not found in tabBarController's viewControllers")
                            }

                            if let createdSetlistsVC = tabBarController.viewControllers?.first(where: { $0 is CreatedSetlistsViewController }) as? CreatedSetlistsViewController {
                                //print("Found CreatedSetlistsViewController")
                                createdSetlistsVC.userId = userId
                                //print("Passed to CreatedSetlistsVC: userId = \(userId ?? "nil")")
                            } else {
                                print("CreatedSetlistsViewController not found in tabBarController's viewControllers")
                            }

                            if let mySetlistsVC = tabBarController.viewControllers?.first(where: { $0 is MySetlistsViewController }) as? MySetlistsViewController {
                                //print("Found MySetlistsViewController")
                                mySetlistsVC.userId = userId
                                //print("Passed to MySetlistsViewController: userId = \(userId ?? "nil")")
                            } else {
                                print("MySetlistsViewController not found in tabBarController's viewControllers")
                            }
                            
                            
                            
                            if let likedSetlistsVC = tabBarController.viewControllers?.first(where: { $0 is LikedSetlistsViewController }) as? LikedSetlistsViewController {
                                //print("Found LikedSetlistsViewController")
                                likedSetlistsVC.userId = userId
                                //print("Passed to LikedSetlistsViewController: userId = \(userId ?? "nil")")
                            } else {
                                print("LikedSetlistsViewController not found in tabBarController's viewControllers")
                            }

                            self.present(tabBarController, animated: true, completion: nil)
                        } else {
                            print("Tab Bar Controller not found")
                        }
                    }
                } else {
                    DispatchQueue.main.async {
                        self.showAlert(message: errorMessage ?? "Unknown error occurred")
                    }
                }
            }
        }

        func showAlert(message: String) {
            let alert = UIAlertController(title: "Login Failed", message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        
        @IBAction func registerButton(_ sender: Any) {
            
        }
    }
