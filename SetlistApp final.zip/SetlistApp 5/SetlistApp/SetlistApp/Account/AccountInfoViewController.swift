//
//  AccountInfoViewController.swift
//  SetlistApp
//
//  Created by Student on 3/14/25.
//

import UIKit

class AccountInfoViewController: UIViewController {
   
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var emailLabel: UILabel!
    
    @IBOutlet weak var infoStackView: UIStackView!
    
    @IBOutlet weak var logoutButton: UIButton!
    
    var userId: String?
    var userName: String?
    var userEmail: String?

    override func viewDidLoad() {
        super.viewDidLoad()

       
        //check if data is there
        //print("AccountInfoViewController viewDidLoad: userName = \(userName ?? "nil"), userEmail = \(userEmail ?? "nil")")

        if let userName = userName {
            nameLabel.text = userName
        }
        if let userEmail = userEmail {
            emailLabel.text = userEmail
        }
        
        //check userId
        if let userId = userId {
            //print("Logged in with user ID: \(userId)")
        }
        
                
            view.backgroundColor = .systemBackground
            setupHeader(title: "Account Info ")
        
        
        
        let stackContainer = UIView()
        stackContainer.backgroundColor = .white
        stackContainer.layer.cornerRadius = 16
        stackContainer.layer.shadowColor = UIColor.black.cgColor
        stackContainer.layer.shadowOpacity = 0.1
        stackContainer.layer.shadowOffset = CGSize(width: 0, height: 2)
        stackContainer.layer.shadowRadius = 6

        stackContainer.addSubview(infoStackView)
        infoStackView.translatesAutoresizingMaskIntoConstraints = false

        NSLayoutConstraint.activate([
            infoStackView.topAnchor.constraint(equalTo: stackContainer.topAnchor, constant: 20),
            infoStackView.leadingAnchor.constraint(equalTo: stackContainer.leadingAnchor, constant: 20),
            infoStackView.trailingAnchor.constraint(equalTo: stackContainer.trailingAnchor, constant: -20),
            infoStackView.bottomAnchor.constraint(equalTo: stackContainer.bottomAnchor, constant: -20)
        ])

        
        view.addSubview(stackContainer)
        stackContainer.translatesAutoresizingMaskIntoConstraints = false

        NSLayoutConstraint.activate([
            stackContainer.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -80),
            stackContainer.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 30),
            stackContainer.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -30),
            
        ])
        
        
    }
    
    @IBAction func logoutButton(_ sender: Any) {
        
        userId = nil
        userName = nil
        userEmail = nil
        self.dismiss(animated: true, completion: nil)
        
    }
    
    func setupHeader(title: String) {
        let headerView = UIView()
            headerView.backgroundColor = UIColor.systemGray6
            headerView.translatesAutoresizingMaskIntoConstraints = false
            view.addSubview(headerView)
            
            NSLayoutConstraint.activate([
                headerView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
                headerView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
                headerView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
                headerView.heightAnchor.constraint(equalToConstant: 44)
            ])
            
            let titleLabel = UILabel()
            titleLabel.text = title
            titleLabel.font = UIFont.systemFont(ofSize: 17, weight: .regular)
            titleLabel.textColor = .darkGray
            titleLabel.translatesAutoresizingMaskIntoConstraints = false
            headerView.addSubview(titleLabel)
            
            NSLayoutConstraint.activate([
                titleLabel.centerXAnchor.constraint(equalTo: headerView.centerXAnchor),
                titleLabel.centerYAnchor.constraint(equalTo: headerView.centerYAnchor)
            ])
    }
    
}
