//
//  RegisterViewController.swift
//  SetlistApp
//
//  Created by Student on 3/14/25.
//

import UIKit

class RegisterViewController: UIViewController {
    
    @IBOutlet weak var name: UITextField!
    
    
    @IBOutlet weak var email: UITextField!
    
    @IBOutlet weak var password: UITextField!
    
    @IBOutlet weak var registerButton: UIButton!
    
    override func viewDidLoad() {
            super.viewDidLoad()
        }

    @IBAction func registerButtonTapped(_ sender: Any) {
        
        guard let name = name.text, !name.isEmpty,
              let email = email.text, !email.isEmpty,
              let password = password.text, !password.isEmpty else {
            showAlert(title: "Error", message: "Please fill in all fields.")
            return
        }
        
        UserDataService.shared.registerUser(name: name, email: email, password: password) { success, errorMessage in
            DispatchQueue.main.async {
                if success {
                    self.showAlert(title: "Success", message: "User registered successfully!") {
                    self.dismiss(animated: true, completion: nil) 
                }
            } else {
                self.showAlert(title: "Registration Failed", message: errorMessage ?? "Unknown error")
                }
            }
        }
        
        if let navigationController = self.navigationController {
            
                navigationController.popToRootViewController(animated: true)
            }
    }
    
    private func showAlert(title: String, message: String, completion: (() -> Void)? = nil) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { _ in
                    completion?()
        }))
        present(alert, animated: true)
    }
    
    
    
}
