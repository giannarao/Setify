//
//  AppDelegate.swift
//  SetlistApp
//
//  Created by Student on 3/21/25.
//

import UIKit

@main
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    
    let setlistDataService = SetlistDataService()
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        
        //works
        //print("Artists from mongodb:\n ")
        //ArtistDataService.shared.fetchArtists()
        
        //works
        //                print("\nSongs from mongodb:\n ")
        //                SongDataService.shared.fetchSongs()
        //                print("\nSongs by song id test:\n")
        //SongDataService.shared.fetchSongByID(songId: "67acc7093202a073d0b26e0f")
        //returns song title, artist id, artist name, artist image for given song id
        
        //
        
        //works
        //                print("\nUsers from mongodb:\n ")
        //                UserDataService.shared.fetchUsers()
        //                UserDataService.shared.fetchUsers { users, error in
        //                if let error = error {
        //                    print("Error getting users: \(error.localizedDescription)")
        //                } else if let users = users {
        //                        print("Users:")
        //                        for user in users {
        //                        print("ID: \(user.id), Name: \(user.name), Email: \(user.email), Favorites:                               \(user.favoriteSetlists)")
        //                        }
        //                    }
        //                }
        
        //works
        //                print("\nSetlists from mongodb:\n ")
        //                SetlistDataService.shared.fetchSetlists()
        
        
        //        SongDataService.shared.fetchSongByID(songId: "67acc6033202a073d0b26e0c") { song in
        //            if let song = song {
        //                print("Song fetched: \(song.songTitle), Artist IDs: \(song.artistIDs), ID: \(song.id)")
        //            } else {
        //                print("Failed to fetch song details.")
        //            }
        //        }
        
        
        
        
        
        //test add setlist
        //        let createdByObjectId = "67aa58c674836577c31ce62b"
        //        let headlinerObjectId = "67acc5a93202a073d0b26e0a"
        //        let songObjectIds: [String] = [
        //            "67acc5bf3202a073d0b26e0b",
        //            "67acc6033202a073d0b26e0c"
        //        ]
        //
        //
        //        let openerData = [
        //            ["name": "Opener 1", "songs": ["67acc7093202a073d0b26e0f", "67acc7093202a073d0b26e0f"]],
        //            ["name": "Opener 2", "songs": ["67acc7093202a073d0b26e0f"]]
        //        ]
        //
        //        //just trying to populate names now
        //        let openerNames = openerData.map { $0["name"] as? String ?? "" }
        //
        //
        //        let newSetlist = Setlist(
        //            id: "12345",
        //            setlistName: "New Tour2",
        //            setlistImage: "imageName.jpg",
        //            createdBy: createdByObjectId,
        //            tourName: "Patterns Tour",
        //            headlinerName: headlinerObjectId,
        //            dateLocation: [DateLocation(date: "2025-08-04T00:00:00Z", city: "Michigan")],
        //            openerNames: openerNames,
        //            headlinerSongIDs: songObjectIds
        //        )
        
        //        setlistDataService.addSetlist(setlist: newSetlist) { success, error in
        //            if success {
        //                print("Setlist added successfully!")
        //            } else if let error = error {
        //                print("Error adding setlist: \(error.localizedDescription)")
        //            } else {
        //                print("Failed to add setlist.")
        //            }
        //        }
        
        
        
        
        
        
//                let setlist = Setlist(
//                    id: "1",
//                    setlistName: "Tour New Test",
//                    setlistImage: "imageName.jpg",
//                    createdBy: "67aa58c674836577c31ce62b",
//                    tourName: "Tour Name",
//                    headlinerName: "67acc5a93202a073d0b26e0a",
//                    dateLocation: [
//                        DateLocation(date: "2025-03-24T00:00:00.000Z", city: "New York")
//                    ],
//                    openerNames: [
//                        "67acc6f73202a073d0b26e0e", // Opener 1
//                        "67a38747ae5b51c596451e66"  // Opener 2
//                    ],
//                    headlinerSongIDs: [
//                        "67acc5bf3202a073d0b26e0b",
//                        "67acc6033202a073d0b26e0c"
//                    ],
//                    actualArtistNames: [],
//                    actualOpenerNames: [],
//                    actualHeadlinerSongNames: [],
//                    actualOpenerSongNames: []
//                )
//
//                let openerSongs: [String: [String]] = [
//                    "67acc6f73202a073d0b26e0e": [ // Opener 1
//                        "67a3979107993a01c66de4f3", // Song 1
//                        "67acc7093202a073d0b26e0f"  // Song 2
//                    ],
//                    "67a38747ae5b51c596451e66": [ // Opener 2
//                        "67acc7093202a073d0b26e0f"  // Song 1
//                    ]
//                ]
//
//
//                SetlistDataService.shared.addSetlist(setlist: setlist, openerSongs: openerSongs) { success, error in
//                    if success {
//                        print("Setlist added successfully.")
//                    } else if let error = error {
//                        print("Failed to add setlist: \(error.localizedDescription)")
//                    } else {
//                        print("Failed to add setlist: Unknown error.")
//                    }
//                }
//
        
        
        
        
        
        
        
        
        
        
//        let songTitle = "Patterns" // Example song title to search
//        
//        // Call the fetchSongByTitle function to get the song
//        SongDataService().fetchSongByTitle(songTitle: songTitle) { song in
//            if let song = song {
//                print("Song Title: \(song.songTitle)")
//                print("Audio: \(song.audio)")
//                print("Lyrics: \(song.lyrics)")
//                
//                // You can also do any additional processing here with the song data.
//            } else {
//                print("Song not found or an error occurred.")
//            }
//        }
    

        
//        let artistDataService = ArtistDataService()
//        
//        let artistName = "Kelsea Ballerini"
//        
//        artistDataService.fetchArtistByName(artistName: artistName) { artist in
//                    if let artist = artist {
//                        print("Fetched artist: \(artist.artistName)")
//                        
//                    } else {
//                        print("Failed to fetch artist")
//                    }
//                }
        
        
       
//        testFetchSongByTitle(songTitle: "Patterns")
//                
//                // Test fetchSongByTitleDTO (DTO Method)
//                testFetchSongByTitleDTO(songTitle: "Patterns")
        
        
        
        
        
//        let setlistId = "67acc6213202a073d0b26e0d"  // Replace with a valid setlist ID from your backend
//                
//                // Call the fetchSetlistById function from SetlistDataService
//                SetlistDataService().fetchSetlistById(id: setlistId) { result in
//                    switch result {
//                    case .success(let setlist):
//                        // Successfully fetched and decoded the setlist
//                        print("Successfully fetched setlist: \(setlist)")
//
//                        // You can now use the setlist data here, e.g., updating the UI or storing it
//                        // For instance, updating a model or UI element if required
//
//                    case .failure(let error):
//                        // Handle the error
//                        print("Error fetching setlist: \(error.localizedDescription)")
//                    }
//                }
                
        
        
//        67a386f9ae5b51c596451e65
//        UserDataService.shared.fetchUserById(userId: "67ec36501b32dbb877a98f68") { user in
//            if let user = user {
//                print("User fetched:")
//                print("Id: \(user.id)")
//                print("Name: \(user.name)")
//                print("Email: \(user.email)")
//                print("Password: \(user.password)")
//                if let favorites = user.favoriteSetlists {
//                    print("Favorite Setlists: \(favorites)")
//                } else {
//                    print("Favorite Setlists: None")
//                }
//            } else {
//                print("Failed to fetch user by ID")
//            }
//        }
        
        
        
        //SetlistDataService.shared.fetchSetlistsByUser(userId: "67a386f9ae5b51c596451e65")
                
        
        
        
//        ArtistDataService.shared.addArtist(artistName: "Test Artist from AppDelegate", artistImage: "test-image.jpg") { result in
//                switch result {
//                case .success(let artist):
//                    print("Artist added: \(artist)")
//                case .failure(let error):
//                    print("Failed to add artist:", error.localizedDescription)
//                }
//            }
        
        
//        ArtistDataService.shared.getOrCreateArtist(artistName: "Test from App Delegate") { artistId in
//                    if let artistId = artistId {
//                        print("Artist ID for 'Test from App Delegate': \(artistId)")
//                    } else {
//                        print("Error: Could not fetch or create artist.")
//                    }
//                }
        
        
        
        
//        SongDataService.shared.getOrAddSong(songTitle: "Cowboys Cry Too", artistName: "Kelsea Ballerini") { song in
//                    if let song = song {
//                        print("Song fetched or added: \(song.songTitle) with ID: \(song.id)")
//                    } else {
//                        print("Failed to fetch or add the song.")
//                    }
//                }
        
        
        
//        let userId = "67a386f9ae5b51c596451e65" // Replace with a valid user ID
//
//                // Call getFavoriteSetlists to fetch the favorite setlists
//        UserDataService().getFavoriteSetlists(userId: userId) { result in
//                    switch result {
//                    case .success(let favoriteSetlists):
//                        print("Favorite Setlists: \(favoriteSetlists)")
//                    case .failure(let error):
//                        print("Error fetching favorite setlists: \(error.localizedDescription)")
//                    }
//                }
        
        let userId = "67a386f9ae5b51c596451e65"  // Provide a valid user ID
                let setlistId = "680443b898db10bb0a18c99f"  // Provide a valid setlist ID
                
                // Call the updateFavoriteSetlist function to remove the setlist from favorites
        SetlistDataService.shared.updateFavoriteSetlist(setlistId: setlistId, userId: userId, favoriteStatus: true) { result in
                    switch result {
                    case .success(let updatedFavoriteSetlists):
                        // Handle the updated list of favorite setlists
                        print("Favorite setlists updated: \(updatedFavoriteSetlists)")
                    case .failure(let error):
                        // Handle error
                        print("Error updating favorite status: \(error.localizedDescription)")
                    }
                }
            
        
        
        
        return true
    }
    
    func testFetchSongByTitle(songTitle: String) {
            SongDataService.shared.fetchSongByTitle(songTitle: songTitle) { song in
                if let song = song {
                    print("Normal fetchSongByTitle - Song Title: \(song.songTitle), Song ID: \(song.id), Audio: \(song.audio), Lyrics: \(song.lyrics)")
                    
                    for artistID in song.artistIDs {
                        print("Artist ID: \(artistID)")
                    }
                } else {
                    print("Failed to fetch song details using fetchSongByTitle.")
                }
            }
        }

    
        func testFetchSongByTitleDTO(songTitle: String) {
            SongDataService.shared.fetchSongByTitleDTO(songTitle: songTitle) { songDTO in
                if let songDTO = songDTO {
                    print("DTO fetchSongByTitleDTO - Song Title: \(songDTO.songTitle), Song ID: \(songDTO.id), Audio: \(songDTO.audio), Lyrics: \(songDTO.lyrics)")
                    
                    for artist in songDTO.artistIDs {
                        print("Artist Name: \(artist.artistName), Artist Image: \(artist.artistImage ?? "No image available")")
                    }
                } else {
                    print("Failed to fetch song details using fetchSongByTitleDTO.")
                }
            }
        }


    
    
    
    
    
    
    
    
    // MARK: UISceneSession Lifecycle

    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        // Called when a new scene session is being created.
        // Use this method to select a configuration to create the new scene with.
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }

    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        // Called when the user discards a scene session.
        // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
        // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
    }


}

