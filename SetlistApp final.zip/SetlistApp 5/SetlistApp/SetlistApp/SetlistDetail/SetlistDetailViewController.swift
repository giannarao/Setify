//
//  SetlistDetailViewController.swift
//  SetlistApp
//
//  Created by Student on 3/14/25.
//

import UIKit

class SetlistDetailViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
//    let baseURL = "http://localhost:3000/api/setlists"
    let baseURL = "http://10.71.40.198:3000/api/setlists"

   
    @IBOutlet weak var favoriteButton: UIButton!
    
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var setlistName: UILabel!
    
    @IBOutlet weak var tourName: UILabel!
    
    @IBOutlet weak var concertDate: UILabel!
    
    @IBOutlet weak var concertCity: UILabel!
    
    @IBOutlet weak var artistsInSetlist: UILabel!
    
    @IBOutlet weak var setlistInputStackView: UIStackView!
    
    @IBOutlet weak var createdBy: UILabel!
    
    var isFavorited = false
    
    
    var setlistId: String?
        var artistSongs: [String: [String]] = [:]
        var songAudioLinks: [String: String] = [:]
        var songLyricsLinks: [String: String] = [:]
    var userId: String? 

        override func viewDidLoad() {
            super.viewDidLoad()
            tableView.dataSource = self
            
            tableView.delegate = self
            
            
            styleSetlistInputStackView()
            
            
            
            if let id = setlistId, let userId = userId {
//                print("Received Setlist ID: \(id)")
                fetchSetlistDetails(for: id)
                fetchFavoriteStatus(for: setlistId ?? "", userId: userId)
                    }
            
        }
    
    
    @IBAction func favoriteButtonTapped(_ sender: Any) {
        guard let button = sender as? UIButton else {
                return
            }

            isFavorited.toggle()
            updateFavoriteButtonUI()

            UIView.animate(withDuration: 0.1, animations: {
                
                button.transform = CGAffineTransform(scaleX: 1.2, y: 1.2)
            }) { _ in
                UIView.animate(withDuration: 0.1) {
                    
                    button.transform = .identity
                }
            }
      
        
        SetlistDataService().updateFavoriteSetlist(
            setlistId: setlistId ?? "",
            userId: userId ?? "",
                favoriteStatus: isFavorited
            ) { result in
                DispatchQueue.main.async {
                    switch result {
                    case .success(let updatedFavorites):
                        print("Favorite setlists updated: \(updatedFavorites)")
                    case .failure(let error):
                        print("Failed to update favorite: \(error.localizedDescription)")
                        // Optionally revert UI if needed
                        self.isFavorited.toggle()
                        self.updateFavoriteButtonUI()
                    }
                }
            }
    }
    
    
    
    
    func fetchFavoriteStatus(for setlistId: String, userId: String) {
        
        UserDataService().getFavoriteSetlists(userId: userId) { result in
            switch result {
            case .success(let favoriteSetlists):
                        let isFavorite = favoriteSetlists.contains(setlistId)

                        DispatchQueue.main.async {
                            self.isFavorited = isFavorite
                            self.updateFavoriteButtonUI()
                        }
                
                
            case .failure(let error):
                print("Failed to fetch favorite setlists: \(error.localizedDescription)")
            }
        }
    }
    
    func updateFavoriteButtonUI() {
        let starImageName = isFavorited ? "star.fill" : "star"
            let starImage = UIImage(systemName: starImageName)
            favoriteButton.setImage(starImage, for: .normal)
            favoriteButton.tintColor = isFavorited ? .systemYellow : .lightGray
    }
    
    

    
    
    func styleSetlistInputStackView() {
        
        setlistInputStackView.backgroundColor = UIColor.systemGray6
        
        setlistInputStackView.layer.cornerRadius = 10
        setlistInputStackView.layer.masksToBounds = true
        
        setlistInputStackView.layoutMargins = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        setlistInputStackView.isLayoutMarginsRelativeArrangement = true
        
        setlistInputStackView.layer.shadowColor = UIColor.black.cgColor
        setlistInputStackView.layer.shadowOpacity = 0.05
        setlistInputStackView.layer.shadowOffset = CGSize(width: 0, height: 1)
        setlistInputStackView.layer.shadowRadius = 5
    }
    
    
        func fetchSetlistDetails(for id: String) {
            
            let urlString = "\(baseURL)/\(id)"

            guard let url = URL(string: urlString) else { return }
            
            
            URLSession.shared.dataTask(with: url) { data, response, error in
                if let error = error {
                    print("Error fetching setlist details: \(error)")
                    return
                }
                
                guard let data = data else { return }
                
                do {
                    let decoder = JSONDecoder()
                    let setlist = try decoder.decode(SetlistUploadDTO.self, from: data)
                    
                    DispatchQueue.main.async {
//                        print("Setlist JSON:\n\(String(data: data, encoding: .utf8) ?? "")")
                        
                        self.setlistName.text = setlist.setlistName
                        self.tourName.text = setlist.tourName

                        if let date = setlist.date_location.first?.date, let city = setlist.date_location.first?.city {
                            self.concertDate.text = self.formatDate(date)
                            self.concertCity.text = city
                        }
                        
//                        print("Fetched Setlist, createdBy ID: \(setlist.createdBy)")
                        
                        self.fetchCreatedByUser(userId: setlist.createdBy)
                        
                        let allArtists = setlist.actualArtistNames + setlist.actualOpenerNames
                        self.artistsInSetlist.text = allArtists.joined(separator: ", ")
                        
                        self.groupSongsByArtist(setlist: setlist)
                        
                        self.tableView.reloadData()
                    }
                } catch {
                    print("Error decoding setlist: \(error)")
                }
            }.resume()
        }
        
        func fetchCreatedByUser(userId: String) {
//            print("Fetching user for createdBy ID: \(userId)")
            
            UserDataService.shared.fetchUserById(userId: userId) { user in
                if let user = user {
                    DispatchQueue.main.async {
//                        print("User fetched: \(user.name)")
                        self.createdBy.text = "Created by: \(user.name)"
                    }
                } else {
                    DispatchQueue.main.async {
                        print("User not found for createdBy ID: \(userId)")  
                        self.createdBy.text = "Created by: Unknown"
                    }
                }
            }
        }

        func formatDate(_ dateString: String) -> String {
            let formatter = DateFormatter()
            formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSZ"
            if let date = formatter.date(from: dateString) {
                formatter.dateStyle = .medium
                formatter.timeStyle = .none
                return formatter.string(from: date)
            }
            return dateString
        }

        // MARK: - Group Songs by Artist
        
    func groupSongsByArtist(setlist: SetlistUploadDTO) {
        
        var groupedSongs: [String: [String]] = [:]
            var artistNameMap: [String: String] = [:]
            var songTitleMap: [String: String] = [:]

//            print("Starting grouping of openers...")

            let openerIDs = setlist.openerNames.map { $0.name }
            let openerDispatchGroup = DispatchGroup()

            for artistID in openerIDs {
                openerDispatchGroup.enter()
                ArtistDataService.shared.fetchArtistByID(artistID: artistID) { artist in
                    if let artist = artist {
                        artistNameMap[artistID] = artist.artistName
//                        print("Opener Artist: \(artist.artistName)")
                    } else {
                        print("Failed to fetch opener for ID: \(artistID)")
                    }
                    openerDispatchGroup.leave()
                }
            }

            var allSongIDs: [String] = []
            for opener in setlist.openerNames {
                allSongIDs.append(contentsOf: opener.songs)
            }

            for songID in setlist.headlinerSongIDs {
                allSongIDs.append(songID)
            }

            let uniqueSongIDs = Set(allSongIDs)
            let songDispatchGroup = DispatchGroup()

            for songID in uniqueSongIDs {
                songDispatchGroup.enter()
                SongDataService.shared.fetchSongByID(songId: songID) { song in
                    if let song = song {
                        songTitleMap[songID] = song.songTitle
                        DispatchQueue.main.async {
                            self.songAudioLinks[song.songTitle] = song.audio
                            self.songLyricsLinks[song.songTitle] = song.lyrics
                        }
                    } else {
                        print("Failed to fetch song for ID: \(songID)")
                    }
                    songDispatchGroup.leave()
                }
            }

            openerDispatchGroup.notify(queue: .main) {
                songDispatchGroup.notify(queue: .main) {
                    // Group opener songs
                    for opener in setlist.openerNames {
                        guard let artistName = artistNameMap[opener.name] else { continue }
                        let songTitles = opener.songs.compactMap { songTitleMap[$0] }
//                        print("\(artistName): \(songTitles)")
                        groupedSongs[artistName] = songTitles
                    }
                    
                    for (index, headlinerID) in [setlist.headlinerName].enumerated() {
                                    ArtistDataService.shared.fetchArtistByID(artistID: headlinerID) { artist in
                                        guard let artist = artist else {
                                            print("Failed to fetch headliner artist for ID: \(headlinerID)")
                                            return
                                        }
                                        let songTitles = setlist.headlinerSongIDs.compactMap { songTitleMap[$0] }
                                        groupedSongs[artist.artistName] = songTitles
//                                        print("Headliner: \(artist.artistName)")
//                                        print("Songs: \(songTitles)")

                                        // Set and reload final data
                                        self.artistSongs = groupedSongs
//                                        print("Final grouped songs:")
                                        for (artist, songs) in groupedSongs {
//                                            print("\(artist): \(songs)")
                                        }

                                        DispatchQueue.main.async {
                                            self.tableView.reloadData()
                                        }
                                    }
                                }
                            }
                        }
                    
                    
                
        
            }

        // MARK: - UITableViewDataSource
    
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView()
        headerView.backgroundColor = UIColor.white
        
        let headerLabel = UILabel()
        headerLabel.text = Array(artistSongs.keys)[section]
        headerLabel.font = UIFont.boldSystemFont(ofSize: 20)
        headerLabel.textColor = UIColor.darkText
        headerLabel.lineBreakMode = .byClipping
        headerLabel.numberOfLines = 1
        headerLabel.translatesAutoresizingMaskIntoConstraints = false
        
        headerView.addSubview(headerLabel)
        
        NSLayoutConstraint.activate([
            headerLabel.leadingAnchor.constraint(equalTo: headerView.leadingAnchor, constant: 15),
            headerLabel.trailingAnchor.constraint(equalTo: headerView.trailingAnchor, constant: -15),
            headerLabel.centerYAnchor.constraint(equalTo: headerView.centerYAnchor),
            headerLabel.topAnchor.constraint(greaterThanOrEqualTo: headerView.topAnchor, constant: 10),
            headerLabel.bottomAnchor.constraint(lessThanOrEqualTo: headerView.bottomAnchor, constant: -10)
        ])
        
        return headerView
    }
    
    
    
    
        func numberOfSections(in tableView: UITableView) -> Int {
            return artistSongs.keys.count
        }
        
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            let artistName = Array(artistSongs.keys)[section]
            return artistSongs[artistName]?.count ?? 0
        }
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "SetlistDetailCell", for: indexPath) as? SetlistDetailCell else {
                return UITableViewCell()
            }
            
            let artistName = Array(artistSongs.keys)[indexPath.section]
            if let song = artistSongs[artistName]?[indexPath.row] {
                cell.songName.text = song
                
                let tag = indexPath.section * 1000 + indexPath.row
                cell.audioButton.tag = tag
                cell.lyricsButton.tag = tag

                cell.audioButton.addTarget(self, action: #selector(listenButtonTapped(_:)), for: .touchUpInside)
                cell.lyricsButton.addTarget(self, action: #selector(lyricsButtonTapped(_:)), for: .touchUpInside)
            }
            
            return cell
        }
    
    
        
        func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
           return Array(artistSongs.keys)[section]
            
        }

        @objc func listenButtonTapped(_ sender: UIButton) {
            let indexPath = indexPathFromTag(sender.tag)
            let artist = Array(artistSongs.keys)[indexPath.section]
            let songTitle = artistSongs[artist]?[indexPath.row]
            
            if let song = songTitle, let link = songAudioLinks[song], let url = URL(string: link) {
//                print("Audio button tapped: \(song) - \(link)")

                if let webViewController = self.storyboard?.instantiateViewController(withIdentifier: "WebViewController") as? WebViewController {
                    webViewController.urlToLoad = url
                    self.present(webViewController, animated: true, completion: nil)
                }
            } else {
                print("Invalid audio link for song: \(songTitle ?? "Unknown")")
            }
        }
        
        @objc func lyricsButtonTapped(_ sender: UIButton) {
            let indexPath = indexPathFromTag(sender.tag)
            let artist = Array(artistSongs.keys)[indexPath.section]
            let songTitle = artistSongs[artist]?[indexPath.row]

            if let song = songTitle, let link = songLyricsLinks[song], let url = URL(string: link) {
//                print("Lyrics button tapped: \(song) - \(link)")

                if let webViewController = self.storyboard?.instantiateViewController(withIdentifier: "WebViewController") as? WebViewController {
                    webViewController.urlToLoad = url
                    self.present(webViewController, animated: true, completion: nil)
                }
            } else {
                print("Invalid lyrics link for song: \(songTitle ?? "Unknown")")
            }
        }

        func indexPathFromTag(_ tag: Int) -> IndexPath {
            let section = tag / 1000
            let row = tag % 1000
            return IndexPath(row: row, section: section)
        }
    
    }
