//
//  WebViewController.swift
//  SetlistApp
//
//  Created by Student on 4/15/25.
//

import UIKit
import WebKit

class WebViewController: UIViewController {
    var urlToLoad: URL?

    override func viewDidLoad() {
        super.viewDidLoad()

        let webView = WKWebView(frame: self.view.frame)
        self.view.addSubview(webView)

        if let url = urlToLoad {
            let request = URLRequest(url: url)
            webView.load(request)
        }
        
        addCloseButton()

    }

    func addCloseButton() {
        
        let closeButton = UIButton(type: .system)
                closeButton.setTitle("X", for: .normal)
                closeButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 24)
        closeButton.frame = CGRect(x: self.view.frame.width - 60, y: 10, width: 40, height: 40)
                
                closeButton.backgroundColor = .red
                closeButton.layer.cornerRadius = 20
                closeButton.setTitleColor(.white, for: .normal)
                
                closeButton.addTarget(self, action: #selector(dismissWebView), for: .touchUpInside)
                
                self.view.addSubview(closeButton)
             
    }
    
    @objc func dismissWebView() {
        self.dismiss(animated: true, completion: nil)
    }
    
}


