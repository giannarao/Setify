//
//  SetlistDetailCell.swift
//  SetlistApp
//
//  Created by Student on 3/14/25.
//

import UIKit

class SetlistDetailCell: UITableViewCell {
    
    @IBOutlet weak var songName: UILabel!
    
    var audioButton: UIButton!
        var lyricsButton: UIButton!
        
    
        var song: Song?

        override func awakeFromNib() {
            super.awakeFromNib()
            
            setupAudioButton()
            setupLyricsButton()
        }
        
        func setupAudioButton() {
            audioButton = UIButton(type: .system)
            audioButton.setTitle("Listen", for: .normal)
            audioButton.translatesAutoresizingMaskIntoConstraints = false
            audioButton.addTarget(self, action: #selector(audioButtonTapped), for: .touchUpInside)
            contentView.addSubview(audioButton)
            
            NSLayoutConstraint.activate([
                audioButton.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 10),
                audioButton.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
                audioButton.widthAnchor.constraint(equalToConstant: 80)
            ])
        }
        
        func setupLyricsButton() {
            lyricsButton = UIButton(type: .system)
            lyricsButton.setTitle("Lyrics", for: .normal)
            lyricsButton.translatesAutoresizingMaskIntoConstraints = false
            lyricsButton.addTarget(self, action: #selector(lyricsButtonTapped), for: .touchUpInside)
            contentView.addSubview(lyricsButton)
            
            NSLayoutConstraint.activate([
                lyricsButton.leadingAnchor.constraint(equalTo: audioButton.trailingAnchor, constant: 10),
                lyricsButton.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
                lyricsButton.widthAnchor.constraint(equalToConstant: 80)
            ])
        }
        
        func configure(with song: Song) {
            self.song = song
            songName.text = song.songTitle
            
            audioButton.isEnabled = !song.audio.isEmpty
            lyricsButton.isEnabled = !song.lyrics.isEmpty
        }

        @objc func audioButtonTapped() {
            guard let selectedSong = song else {
                //print("No song selected.")
                return
            }
            
            let audioLink = selectedSong.audio
            if audioLink.isEmpty {
                print("Invalid audio link: The audio link is empty.")
                return
            }
            
            var formattedAudioLink = audioLink
            
            if !formattedAudioLink.lowercased().hasPrefix("http://") && !formattedAudioLink.lowercased().hasPrefix("https://") {
                formattedAudioLink = "http://" + formattedAudioLink
            }
            
            if let url = URL(string: formattedAudioLink) {
                if UIApplication.shared.canOpenURL(url) {
                    UIApplication.shared.open(url)
                } else {
                    print("Cannot open the Audio URL: \(url)")
                }
            } else {
                print("Invalid Audio URL: The URL is malformed.")
            }
        }
        
        @objc func lyricsButtonTapped() {
            guard let selectedSong = song else {
                //print("No song selected.")
                return
            }
            
            let lyricsLink = selectedSong.lyrics
            if lyricsLink.isEmpty {
                print("Invalid lyrics link: The lyrics link is empty.")
                return
            }
            
            var formattedLyricsLink = lyricsLink
            if !formattedLyricsLink.lowercased().hasPrefix("http://") && !formattedLyricsLink.lowercased().hasPrefix("https://") {
                formattedLyricsLink = "http://" + formattedLyricsLink
            }
            
    
            if let url = URL(string: formattedLyricsLink) {
                if UIApplication.shared.canOpenURL(url) {
                    UIApplication.shared.open(url)
                } else {
                    print("Cannot open the Lyrics URL: \(url)")
                }
            } else {
                print("Invalid Lyrics URL: The URL is malformed.")
            }
        }
    }


    


    
