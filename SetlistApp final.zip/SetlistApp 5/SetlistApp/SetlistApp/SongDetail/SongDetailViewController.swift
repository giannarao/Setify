//
//  SongDetailViewController.swift
//  SetlistApp
//
//  Created by Student on 3/21/25.
//

//don't need this file 

import UIKit

class SongDetailViewController: UIViewController, UITableViewDelegate {
    
    @IBOutlet weak var songName: UILabel!
    
    @IBOutlet weak var artistName: UILabel!
    

//
//    var selectedSong: Song?
//            var artists: [String] = [] // Array to hold artist names
//            
//            override func viewDidLoad() {
//                super.viewDidLoad()
//                
//                if let song = selectedSong {
//                    songName.text = song.songTitle
//                    
//                    if !artists.isEmpty {
//                        artistName.text = "Artists: \(artists.joined(separator: ", "))"
//                    } else {
//                        artistName.text = "Artists: Unknown"
//                    }
//                } else {
//                    showError(message: "Song details could not be loaded.")
//                }
//            }
//            
//            func showError(message: String) {
//                let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
//                alert.addAction(UIAlertAction(title: "OK", style: .default))
//                present(alert, animated: true)
//            }
//        }
//
//
//
//
//    
    var selectedSong: Song?
    var artists: [String] = []

    override func viewDidLoad() {
        super.viewDidLoad()

        if let song = selectedSong {
            songName.text = song.songTitle

            if !artists.isEmpty {
                artistName.text = "Artists: \(artists.joined(separator: ", "))"
            } else {
                artistName.text = "Artists: Unknown"
            }
        } else {
            showError(message: "Song details could not be loaded.")
        }
    }
        
        func showError(message: String) {
            let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            present(alert, animated: true)
        }
    }
