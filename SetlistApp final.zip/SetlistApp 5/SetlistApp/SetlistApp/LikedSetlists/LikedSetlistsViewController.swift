//
//  LikedSetlistsViewController.swift
//  SetlistApp
//
//  Created by Student on 3/14/25.
//

import UIKit

class LikedSetlistsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
//    let baseURL = "http://localhost:3000/api/setlists"
        let baseURL = "http://10.71.40.198:3000/api/setlists"
    
    @IBOutlet weak var tableView: UITableView!
    
    
    
    
    var noFavoritesLabel: UILabel!
    
    
    
    
    
        var userId: String?
    
            var favoriteSetlists: [SetlistUploadDTO] = []
    
            override func viewDidLoad() {
                super.viewDidLoad()
    
                tableView.delegate = self
                tableView.dataSource = self
                view.backgroundColor = .systemBackground
                
                setupNoFavoritesLabel()
    
                if let userId = userId {
                    fetchFavoriteSetlists(userId: userId)
                }
    
                view.backgroundColor = .systemBackground
                setupHeader(title: "Liked Setlists")
    
                startPollingForUpdates()
    
    
    
                NotificationCenter.default.addObserver(self, selector: #selector(didFetchFavoriteSetlists(_:)), name: .didFetchSetlists, object: nil)
            }
    
        override func viewWillAppear(_ animated: Bool) {
                super.viewWillAppear(animated)
//            print("View will appear")
            fetchFavoriteSetlists(userId: userId ?? "")
            }
    
    func setupNoFavoritesLabel() {
        noFavoritesLabel = UILabel()
        noFavoritesLabel.text = "No favorites"
        noFavoritesLabel.font = UIFont.systemFont(ofSize: 18, weight: .medium)
        noFavoritesLabel.textColor = .gray
        noFavoritesLabel.textAlignment = .center
        noFavoritesLabel.translatesAutoresizingMaskIntoConstraints = false
        noFavoritesLabel.isHidden = true

        view.addSubview(noFavoritesLabel)

        NSLayoutConstraint.activate([
            noFavoritesLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            noFavoritesLabel.centerYAnchor.constraint(equalTo: view.centerYAnchor)
        ])
    }
    
        func startPollingForUpdates() {
                Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(pollForUpdates), userInfo: nil, repeats: true)
            }
    
            @objc func pollForUpdates() {
                fetchFavoriteSetlists(userId: userId ?? "")
            }
    
    
//            func updateSetlistsUI() {
//                // Reload your table view or collection view here
//                // Example:
//                 self.tableView.reloadData()
//            }
    
    func updateSetlistsUI() {
        DispatchQueue.main.async {
            if self.favoriteSetlists.isEmpty {
                self.noFavoritesLabel.isHidden = false
            } else {
                self.noFavoritesLabel.isHidden = true
            }
            self.tableView.reloadData()
        }
    }
    
    
    
    
    
        func setupHeader(title: String) {
            let headerView = UIView()
                headerView.backgroundColor = UIColor.systemGray6
                headerView.translatesAutoresizingMaskIntoConstraints = false
                view.addSubview(headerView)
    
                NSLayoutConstraint.activate([
                    headerView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
                    headerView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
                    headerView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
                    headerView.heightAnchor.constraint(equalToConstant: 44)
                ])
    
                let titleLabel = UILabel()
                titleLabel.text = title
                titleLabel.font = UIFont.systemFont(ofSize: 17, weight: .regular)
                titleLabel.textColor = .darkGray
                titleLabel.translatesAutoresizingMaskIntoConstraints = false
                headerView.addSubview(titleLabel)
    
                NSLayoutConstraint.activate([
                    titleLabel.centerXAnchor.constraint(equalTo: headerView.centerXAnchor),
                    titleLabel.centerYAnchor.constraint(equalTo: headerView.centerYAnchor)
                ])
        }
    
    
        func fetchFavoriteSetlists(userId: String) {
            UserDataService.shared.getFavoriteSetlists(userId: userId) { result in
                switch result {
                case .success(let favoriteSetlists):
//                    print("Favorite Setlist IDs: \(favoriteSetlists)")
                    
                    self.fetchSetlistDetails(setlistIds: favoriteSetlists)
                case .failure(let error):
                    print("Error fetching favorite setlists: \(error)")
                }
            }
        }
    
    
        func fetchSetlistDetails(setlistIds: [String]) {
           
            var fetchedSetlists: [SetlistUploadDTO] = []

                let dispatchGroup = DispatchGroup()

                for setlistId in setlistIds {
                    dispatchGroup.enter()
                    SetlistDataService.shared.fetchSetlistById(id: setlistId) { result in
                        switch result {
                        case .success(let setlist):
                            fetchedSetlists.append(setlist)
                        case .failure(let error):
                            print("Error fetching setlist details for ID \(setlistId): \(error)")
                        }
                        dispatchGroup.leave()
                    }
                }

                dispatchGroup.notify(queue: .main) {
                    if !fetchedSetlists.isEmpty {
                        self.favoriteSetlists = fetchedSetlists
                        self.tableView.reloadData()
                        self.noFavoritesLabel.isHidden = true
                    } else {
                        self.favoriteSetlists = []
                        self.tableView.reloadData()
                        self.noFavoritesLabel.isHidden = false
                    }
                }
        }
    
    
    
    
    
            @objc func didFetchFavoriteSetlists(_ notification: Notification) {
//                print("Fetched favorite setlists.")
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
            }
    
            // MARK: - Table View Delegate and Data Source
    
            func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
                return favoriteSetlists.count
            }
    
            func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
                let cell = tableView.dequeueReusableCell(withIdentifier: "LikedSetlistCell", for: indexPath)
    
                cell.contentView.subviews.forEach { $0.removeFromSuperview() }
    
                let setlist = favoriteSetlists[indexPath.row]
    
                let setlistNameLabel = UILabel()
                setlistNameLabel.text = setlist.setlistName
                setlistNameLabel.font = UIFont.boldSystemFont(ofSize: 20)
                setlistNameLabel.textColor = .black
                setlistNameLabel.translatesAutoresizingMaskIntoConstraints = false
                setlistNameLabel.numberOfLines = 0
    
                let headlinerLabel = UILabel()
                let headlinerText = setlist.actualArtistNames.first ?? "Unknown Headliner"
                headlinerLabel.text = "Headliner: \(headlinerText)"
                headlinerLabel.font = UIFont.systemFont(ofSize: 16, weight: .medium)
                headlinerLabel.textColor = .black
                headlinerLabel.translatesAutoresizingMaskIntoConstraints = false
                headlinerLabel.numberOfLines = 0 
    
                cell.contentView.addSubview(setlistNameLabel)
                cell.contentView.addSubview(headlinerLabel)
    
                NSLayoutConstraint.activate([
                    setlistNameLabel.topAnchor.constraint(equalTo: cell.contentView.topAnchor, constant: 10),
                    setlistNameLabel.leadingAnchor.constraint(equalTo: cell.contentView.leadingAnchor, constant: 15),
                    setlistNameLabel.trailingAnchor.constraint(equalTo: cell.contentView.trailingAnchor, constant: -15),
    
                    headlinerLabel.topAnchor.constraint(equalTo: setlistNameLabel.bottomAnchor, constant: 5),
                    headlinerLabel.leadingAnchor.constraint(equalTo: setlistNameLabel.leadingAnchor),
                    headlinerLabel.trailingAnchor.constraint(equalTo: setlistNameLabel.trailingAnchor),
                    headlinerLabel.bottomAnchor.constraint(equalTo: cell.contentView.bottomAnchor, constant: -10)
                ])
    
                return cell
            }
    
            func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
                let selectedSetlist = favoriteSetlists[indexPath.row]
//                print("LikedSetlistsViewController: didSelectRowAt - Setlist selected: \(selectedSetlist.setlistName), ID: \(selectedSetlist._id)")
    
                performSegue(withIdentifier: "showSetlistDetail", sender: selectedSetlist)
            }
    
            func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
                return 75 
            }
    
            override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
                if segue.identifier == "showSetlistDetail" {
                    if let setlistDetailVC = segue.destination as? SetlistDetailViewController {
                        if let selectedSetlist = sender as? SetlistUploadDTO {
                            setlistDetailVC.setlistId = selectedSetlist._id
                            setlistDetailVC.userId = self.userId
                        }
                    }
                }
            }
        }
    
    
    
   
