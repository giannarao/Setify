//
//  MySetlistsViewController.swift
//  SetlistApp
//
//  Created by Student on 4/16/25.
//

import UIKit

class MySetlistsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
//    let baseURL = "http://localhost:3000/api/setlists"
    let baseURL = "http://10.71.40.198:3000/api/setlists"
    
    
    
    @IBOutlet weak var tableView: UITableView!
    
    var userId: String?
    var setlists: [SetlistUploadDTO] = []
    
    var noSetlistsLabel: UILabel!
    
    
    
    override func viewDidLoad() {
            super.viewDidLoad()
            
            if let savedUserId = UserDefaults.standard.string(forKey: "userId") {
                userId = savedUserId
//                print("Logged-in User ID: \(userId ?? "No user ID")")
            } else {
                print("No user ID found in UserDefaults")
            }

            if let userId = userId {
                fetchSetlistsByUser(userId: userId)
            }
            
        view.backgroundColor = .systemBackground
        setupHeader(title: "My Setlists")
        
            tableView.delegate = self
            tableView.dataSource = self
        
        setupNoSetlistsLabel()
        
        }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)

        if let userId = userId {
            fetchSetlistsByUser(userId: userId)
        }
    }
    
    func setupNoSetlistsLabel() {
        noSetlistsLabel = UILabel()
        noSetlistsLabel.text = "No setlists"
        noSetlistsLabel.font = UIFont.systemFont(ofSize: 18, weight: .medium)
        noSetlistsLabel.textColor = .gray
        noSetlistsLabel.textAlignment = .center
        noSetlistsLabel.translatesAutoresizingMaskIntoConstraints = false
        noSetlistsLabel.isHidden = true // Initially hidden

        view.addSubview(noSetlistsLabel)

        NSLayoutConstraint.activate([
            noSetlistsLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            noSetlistsLabel.centerYAnchor.constraint(equalTo: view.centerYAnchor)
        ])
    }
    
    

    func setupHeader(title: String) {
        let headerView = UIView()
            headerView.backgroundColor = UIColor.systemGray6
            headerView.translatesAutoresizingMaskIntoConstraints = false
            view.addSubview(headerView)
            
            NSLayoutConstraint.activate([
                headerView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
                headerView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
                headerView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
                headerView.heightAnchor.constraint(equalToConstant: 44)
            ])
            
            let titleLabel = UILabel()
            titleLabel.text = title
            titleLabel.font = UIFont.systemFont(ofSize: 17, weight: .regular)
            titleLabel.textColor = .darkGray
            titleLabel.translatesAutoresizingMaskIntoConstraints = false
            headerView.addSubview(titleLabel)
            
            NSLayoutConstraint.activate([
                titleLabel.centerXAnchor.constraint(equalTo: headerView.centerXAnchor),
                titleLabel.centerYAnchor.constraint(equalTo: headerView.centerYAnchor)
            ])
    }
    
    
    
    
        func fetchSetlistsByUser(userId: String) {
            
            let urlString = "\(baseURL)/user/\(userId)"

                guard let url = URL(string: urlString) else {
                    print("Invalid URL")
                    return
                }

                let task = URLSession.shared.dataTask(with: url) { data, response, error in
                    if let error = error {
                        print("Error fetching setlists by user ID: \(error.localizedDescription)")
                        return
                    }

                    guard let data = data else {
                        print("No data received from server.")
                        return
                    }

                    do {
                        let decoder = JSONDecoder()
                        self.setlists = try decoder.decode([SetlistUploadDTO].self, from: data).reversed()

                        DispatchQueue.main.async {
                            // Update the UI
                            if self.setlists.isEmpty {
                                self.noSetlistsLabel.isHidden = false
                            } else {
                                self.noSetlistsLabel.isHidden = true
                                self.tableView.reloadData()
                            }
                        }
                    } catch {
                        print("Error decoding user setlist data: \(error)")
                    }
                }

                task.resume()
            
            
            
            
        }
    
    func updateSetlistsUI() {
        DispatchQueue.main.async {
            if self.setlists.isEmpty {
                self.noSetlistsLabel.isHidden = false
            } else {
                self.noSetlistsLabel.isHidden = true
            }
            self.tableView.reloadData()
        }
    }
        
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return setlists.count
        }
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "SetlistCell", for: indexPath)

                cell.contentView.subviews.forEach { $0.removeFromSuperview() }

                let setlist = setlists[indexPath.row]

                let setlistNameLabel = UILabel()
                setlistNameLabel.text = setlist.setlistName
                setlistNameLabel.font = UIFont.boldSystemFont(ofSize: 20)
                setlistNameLabel.textColor = .black
                setlistNameLabel.translatesAutoresizingMaskIntoConstraints = false
                setlistNameLabel.numberOfLines = 0

                let headlinerLabel = UILabel()
                let headlinerText = setlist.actualArtistNames.first ?? "Unknown Headliner"
                headlinerLabel.text = "Headliner: \(headlinerText)"
                headlinerLabel.font = UIFont.systemFont(ofSize: 16, weight: .medium)
                headlinerLabel.textColor = .black
                headlinerLabel.translatesAutoresizingMaskIntoConstraints = false
                headlinerLabel.numberOfLines = 0

                cell.contentView.addSubview(setlistNameLabel)
                cell.contentView.addSubview(headlinerLabel)

                NSLayoutConstraint.activate([
                    setlistNameLabel.topAnchor.constraint(equalTo: cell.contentView.topAnchor, constant: 10),
                    setlistNameLabel.leadingAnchor.constraint(equalTo: cell.contentView.leadingAnchor, constant: 15),
                    setlistNameLabel.trailingAnchor.constraint(equalTo: cell.contentView.trailingAnchor, constant: -15),

                    headlinerLabel.topAnchor.constraint(equalTo: setlistNameLabel.bottomAnchor, constant: 5),
                    headlinerLabel.leadingAnchor.constraint(equalTo: setlistNameLabel.leadingAnchor),
                    headlinerLabel.trailingAnchor.constraint(equalTo: setlistNameLabel.trailingAnchor),
                    headlinerLabel.bottomAnchor.constraint(equalTo: cell.contentView.bottomAnchor, constant: -10)
                ])

                return cell
            
        }
        
        func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            
            let selectedSetlist = setlists[indexPath.row]
            
//            print("Selected Setlist: \(selectedSetlist.setlistName)")
            
            performSegue(withIdentifier: "setlistDetailSegue", sender: selectedSetlist)
        }
        
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            return 75
        }
    
        override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            if segue.identifier == "setlistDetailSegue" {
                if let setlistDetailVC = segue.destination as? SetlistDetailViewController {
                    if let selectedSetlist = sender as? SetlistUploadDTO {
//                        print("MySetlistsViewController: prepare(for:sender:) - Passing setlist ID: \(selectedSetlist._id) to SetlistDetailViewController")
                        setlistDetailVC.setlistId = selectedSetlist._id
                        setlistDetailVC.userId = self.userId
                    } else {
                        print("MySetlistsViewController: prepare(for:sender:) - sender is not SetlistUploadDTO")
                    }
                } else {
                    print("MySetlistsViewController: prepare(for:sender:) - Failed to get SetlistDetailViewController from segue destination")
                }
            }
        }
    }
